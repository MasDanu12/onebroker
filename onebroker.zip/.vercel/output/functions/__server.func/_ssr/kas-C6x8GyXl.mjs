import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { C as saldoPabrik, H as cn, I as Page, L as PageHead, M as Button, S as saldoKas, U as LABEL_KAS, f as rupiah, h as masukKas, o as useBuku, p as tgl, w as saldoPenjahit } from "./router-D8i6Q1Lc.mjs";
import { t as ContohBanner } from "./contoh-B6Wjm7H1.mjs";
import { a as TerimaDialog, n as KasbonDialog, r as PribadiDialog, t as BayarDialog } from "./forms-uang-BfwMHYUm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/kas-C6x8GyXl.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function KasPage() {
	const data = useBuku();
	const [tab, setTab] = (0, import_react.useState)("arus");
	const [terima, setTerima] = (0, import_react.useState)(null);
	const [bayar, setBayar] = (0, import_react.useState)(null);
	const [kasbon, setKasbon] = (0, import_react.useState)(null);
	const [pribadi, setPribadi] = (0, import_react.useState)(false);
	const kas = saldoKas(data.kas);
	const pabrik = saldoPabrik(data);
	const jahit = saldoPenjahit(data);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContohBanner, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			title: "Kas",
			lede: "Uang masuk dari pabrik, upah dan kasbon penjahit, plus uang pribadi kalau bayar duluan."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: cn("mb-4 rounded-2xl px-4 py-4", kas < 0 ? "bg-primary text-primary-fg" : "bg-pine text-pine-fg"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: "Saldo kas"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-4xl tabular-nums",
					children: rupiah(kas)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-xl text-sm leading-6 opacity-90",
					children: kas < 0 ? "Kas minus artinya uang pribadi yang dipakai dulu untuk bayar penjahit, belum terganti." : "Kalau pabrik transfer duluan, catat sebagai bayar duluan. Kalau melunasi tagihan, catat sebagai pelunasan."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex flex-wrap gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => setTerima(""),
					children: "Terima dari pabrik"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => setBayar(""),
					children: "Bayar upah"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => setKasbon(""),
					children: "Kasbon penjahit"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: () => setPribadi(true),
					children: "Uang pribadi"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 grid grid-cols-3 gap-2",
			children: [
				["arus", "Arus kas"],
				["pabrik", "Pabrik"],
				["penjahit", "Penjahit"]
			].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setTab(id),
				className: cn("h-11 rounded-xl text-sm font-semibold", tab === id ? "bg-fg text-surface" : "border border-line bg-surface"),
				children: label
			}, id))
		}),
		tab === "arus" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "flex flex-col gap-2",
			children: [data.kas.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "text-sm text-muted",
				children: "Belum ada gerakan kas."
			}) : null, data.kas.slice().sort((a, b) => b.tanggal.localeCompare(a.tanggal) || b.nomor.localeCompare(a.nomor)).map((k) => {
				const masuk = masukKas(k.jenis);
				const lawan = k.pabrikId ? data.pabrik.find((p) => p.id === k.pabrikId)?.nama : data.penjahit.find((p) => p.id === k.penjahitId)?.nama;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-start justify-between gap-3 rounded-2xl border border-line bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted",
								children: [
									k.nomor,
									" · ",
									tgl(k.tanggal)
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: LABEL_KAS[k.jenis]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm text-muted",
								children: [lawan, k.catatan].filter(Boolean).join(" · ") || "—"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: cn("font-semibold tabular-nums", masuk ? "text-pine" : "text-primary"),
							children: [masuk ? "+" : "−", rupiah(k.jumlah)]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mt-1 text-sm font-semibold text-muted",
							onClick: () => {
								if (!window.confirm("Hapus catatan kas ini?")) return;
								const r = data.hapusKas(k.id);
								if (!r.ok) toast.error(r.error);
								else toast.success("Catatan kas dihapus.");
							},
							children: "Hapus"
						})]
					})]
				}, k.id);
			})]
		}) : null,
		tab === "pabrik" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col gap-2",
			children: pabrik.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-2xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl",
							children: p.pabrik.nama
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: p.pabrik.telepon
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-right text-sm font-semibold",
							children: [p.sisa > 0 ? "Harus bayar" : p.sisa < 0 ? "Bayar duluan" : "Lunas", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-base tabular-nums",
								children: rupiah(Math.abs(p.sisa))
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted",
						children: [
							"Tagihan ",
							rupiah(p.tagih),
							" · sudah diterima ",
							rupiah(p.masuk)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex gap-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "px-3",
							onClick: () => setTerima(p.pabrik.id),
							children: "Catat terima"
						})
					})
				]
			}, p.pabrik.id))
		}) : null,
		tab === "penjahit" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col gap-2",
			children: jahit.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-2xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: p.penjahit.nama
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-2 grid grid-cols-3 gap-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Upah belum"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-semibold tabular-nums",
								children: rupiah(p.upahBelum)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Kasbon"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-semibold tabular-nums",
								children: rupiah(p.kasbon)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Masih jahit"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: "font-semibold tabular-nums",
								children: [p.pcsJalan, " pcs"]
							})] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "px-3",
							onClick: () => setBayar(p.penjahit.id),
							children: "Bayar upah"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							className: "px-3",
							onClick: () => setKasbon(p.penjahit.id),
							children: "Kasih kasbon"
						})]
					})
				]
			}, p.penjahit.id))
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TerimaDialog, {
			open: terima !== null,
			onClose: () => setTerima(null),
			pabrikAwal: terima || void 0
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BayarDialog, {
			open: bayar !== null,
			onClose: () => setBayar(null),
			penjahitAwal: bayar || void 0
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KasbonDialog, {
			open: kasbon !== null,
			onClose: () => setKasbon(null),
			penjahitAwal: kasbon || void 0
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PribadiDialog, {
			open: pribadi,
			onClose: () => setPribadi(false)
		})
	] });
}
var SplitComponent = KasPage;
//#endregion
export { SplitComponent as component };
