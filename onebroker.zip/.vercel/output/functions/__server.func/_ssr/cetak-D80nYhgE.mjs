import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { C as saldoPabrik, O as terimaTagihan, _ as nilaiSlip, c as angka, f as rupiah, g as namaDari, o as useBuku, p as tgl, v as nilaiTagihan } from "./router-D8i6Q1Lc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cetak-D80nYhgE.js
var import_jsx_runtime = require_jsx_runtime();
function Kop({ judul, nomor, tanggal }) {
	const profil = useBuku((s) => s.profil);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex items-start justify-between gap-4 border-t-4 border-primary pt-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-3xl leading-none",
				children: profil.nama || "Usaha Makloon"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: profil.pemilik
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: [profil.alamat, profil.telepon].filter(Boolean).join(" · ")
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-right",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-wide text-muted",
					children: judul
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl",
					children: nomor
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: tgl(tanggal, true)
				})
			]
		})]
	});
}
function Tanda({ kiri, kanan }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-12 grid grid-cols-2 gap-8 text-center text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: kiri }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-16 border-t border-line pt-2 text-muted",
			children: "Tanda tangan"
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: kanan }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-16 border-t border-line pt-2 text-muted",
			children: "Tanda tangan"
		})] })]
	});
}
function Kertas({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		className: "mx-auto max-w-2xl rounded-2xl bg-surface p-6 print:rounded-none print:p-0",
		children
	});
}
function CetakAmbil({ id }) {
	const data = useBuku();
	const p = data.pengambilan.find((x) => x.id === id);
	if (!p) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kosong, {});
	const profil = data.profil;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Kertas, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kop, {
			judul: "Nota pengambilan potongan",
			nomor: p.nomor,
			tanggal: p.tanggal
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-6 text-sm",
			children: ["Diterima dari ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-semibold",
				children: namaDari(data.pabrik, p.pabrikId)
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "mt-4 w-full text-left text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-b border-line text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2 font-medium",
						children: "Model"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2 text-right font-medium",
						children: "Qty"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2 text-right font-medium",
						children: "Ongkos / pcs"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2 text-right font-medium",
						children: "Perkiraan"
					})
				]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-b border-line",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-3",
						children: namaDari(data.model, p.modelId)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-3 text-right tabular-nums",
						children: angka(p.qty)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-3 text-right tabular-nums",
						children: rupiah(p.hargaPerPcs)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-3 text-right tabular-nums",
						children: rupiah(p.qty * p.hargaPerPcs)
					})
				]
			}) })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-4 text-sm leading-6 text-muted",
			children: ["Ongkos ditagihkan setelah barang jadi disetor. Perkiraan di atas belum menjadi piutang.", p.catatan ? ` ${p.catatan}` : ""]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tanda, {
			kiri: namaDari(data.pabrik, p.pabrikId),
			kanan: profil.pemilik || profil.nama
		})
	] });
}
function CetakTagihan({ id }) {
	const data = useBuku();
	const t = data.tagihan.find((x) => x.id === id);
	if (!t) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kosong, {});
	const total = nilaiTagihan(t);
	const bayar = terimaTagihan(t.id, data.kas);
	const saldo = saldoPabrik(data).find((p) => p.pabrik.id === t.pabrikId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Kertas, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kop, {
			judul: "Tagihan ongkos jahit",
			nomor: t.nomor,
			tanggal: t.tanggal
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-6 text-sm",
			children: ["Kepada ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-semibold",
				children: namaDari(data.pabrik, t.pabrikId)
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "mt-4 w-full text-left text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-b border-line text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2 font-medium",
						children: "Model"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2 text-right font-medium",
						children: "Qty setor"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2 text-right font-medium",
						children: "Ongkos"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2 text-right font-medium",
						children: "Jumlah"
					})
				]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: t.items.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-b border-line",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-3",
						children: item.modelNama
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-3 text-right tabular-nums",
						children: angka(item.qty)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-3 text-right tabular-nums",
						children: rupiah(item.hargaPerPcs)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-3 text-right tabular-nums",
						children: rupiah(item.qty * item.hargaPerPcs)
					})
				]
			}, `${item.pekerjaanId}-${i}`)) })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
			className: "mt-4 space-y-1 text-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Baris, {
					label: "Total tagihan",
					nilai: rupiah(total),
					tebal: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Baris, {
					label: "Sudah diterima untuk nota ini",
					nilai: rupiah(bayar)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Baris, {
					label: "Sisa nota ini",
					nilai: rupiah(total - bayar),
					tebal: true
				}),
				saldo && saldo.sisa < 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Baris, {
					label: "Uang muka pabrik yang belum terpakai",
					nilai: rupiah(-saldo.sisa)
				}) : null
			]
		}),
		t.catatan ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-sm text-muted",
			children: t.catatan
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tanda, {
			kiri: namaDari(data.pabrik, t.pabrikId),
			kanan: data.profil.pemilik || data.profil.nama
		})
	] });
}
function CetakSlip({ id }) {
	const data = useBuku();
	const s = data.slip.find((x) => x.id === id);
	if (!s) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kosong, {});
	const bruto = nilaiSlip(s);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Kertas, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kop, {
			judul: "Slip upah penjahit",
			nomor: s.nomor,
			tanggal: s.tanggal
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-6 text-sm",
			children: ["Untuk ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-semibold",
				children: namaDari(data.penjahit, s.penjahitId)
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "mt-4 w-full text-left text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-b border-line text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2 font-medium",
						children: "Model"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2 text-right font-medium",
						children: "Qty"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2 text-right font-medium",
						children: "Upah / pcs"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2 text-right font-medium",
						children: "Jumlah"
					})
				]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: s.items.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-b border-line",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-3",
						children: item.modelNama
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-3 text-right tabular-nums",
						children: angka(item.qty)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-3 text-right tabular-nums",
						children: rupiah(item.upahPerPcs)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-3 text-right tabular-nums",
						children: rupiah(item.qty * item.upahPerPcs)
					})
				]
			}, `${item.pekerjaanId}-${i}`)) })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
			className: "mt-4 space-y-1 text-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Baris, {
					label: "Upah kotor",
					nilai: rupiah(bruto)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Baris, {
					label: "Potong kasbon",
					nilai: rupiah(s.potongKasbon)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Baris, {
					label: "Tunai diterima",
					nilai: rupiah(bruto - s.potongKasbon),
					tebal: true
				})
			]
		}),
		s.catatan ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-sm text-muted",
			children: s.catatan
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tanda, {
			kiri: namaDari(data.penjahit, s.penjahitId),
			kanan: data.profil.pemilik || data.profil.nama
		})
	] });
}
function Baris({ label, nilai, tebal }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: tebal ? "flex justify-between font-semibold" : "flex justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "tabular-nums",
			children: nilai
		})]
	});
}
function Kosong() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-center text-sm text-muted",
		children: "Nota tidak ditemukan."
	});
}
//#endregion
export { CetakSlip as n, CetakTagihan as r, CetakAmbil as t };
