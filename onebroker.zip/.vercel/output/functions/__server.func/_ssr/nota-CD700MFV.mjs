import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { I as Page, L as PageHead, M as Button, O as terimaTagihan, _ as nilaiSlip, f as rupiah, g as namaDari, o as useBuku, p as tgl, v as nilaiTagihan } from "./router-D8i6Q1Lc.mjs";
import { t as ContohBanner } from "./contoh-B6Wjm7H1.mjs";
import { i as TagihanDialog } from "./forms-uang-BfwMHYUm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/nota-CD700MFV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function NotaPage() {
	const data = useBuku();
	const [tagihan, setTagihan] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContohBanner, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			title: "Nota",
			lede: "Cetak nota ambil, tagihan ke pabrik, dan slip upah penjahit. Di pratinjau, pilih cetak atau simpan PDF.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setTagihan(true),
				children: "Buat tagihan"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mb-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-2 font-display text-2xl",
				children: "Tagihan ke pabrik"
			}), data.tagihan.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Belum ada tagihan. Setor hasil jahitan dulu, lalu buat tagihan."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: data.tagihan.map((t) => {
					const total = nilaiTagihan(t);
					const bayar = terimaTagihan(t.id, data.kas);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-2xl border border-line bg-surface p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted",
									children: [
										t.nomor,
										" · ",
										tgl(t.tanggal)
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold",
									children: namaDari(data.pabrik, t.pabrikId)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-muted",
									children: [
										t.items.length,
										" baris · diterima ",
										rupiah(bayar),
										" · sisa ",
										rupiah(total - bayar)
									]
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold tabular-nums",
								children: rupiah(total)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/cetak/tagihan/$id",
								params: { id: t.id },
								className: "inline-flex h-11 items-center rounded-xl bg-primary px-4 text-sm font-semibold text-primary-fg",
								children: "Cetak"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "danger",
								onClick: () => {
									if (!window.confirm("Hapus tagihan ini?")) return;
									const r = data.hapusTagihan(t.id);
									if (!r.ok) toast.error(r.error);
									else toast.success("Tagihan dihapus.");
								},
								children: "Hapus"
							})]
						})]
					}, t.id);
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mb-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-2 font-display text-2xl",
				children: "Slip upah penjahit"
			}), data.slip.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Slip terbuat otomatis saat upah dibayar."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: data.slip.map((s) => {
					const bruto = nilaiSlip(s);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-2xl border border-line bg-surface p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-start justify-between gap-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted",
									children: [
										s.nomor,
										" · ",
										tgl(s.tanggal)
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold",
									children: namaDari(data.penjahit, s.penjahitId)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-muted",
									children: [
										"Upah ",
										rupiah(bruto),
										" · potong kasbon ",
										rupiah(s.potongKasbon),
										" · tunai ",
										rupiah(bruto - s.potongKasbon)
									]
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/cetak/slip/$id",
								params: { id: s.id },
								className: "inline-flex h-11 items-center rounded-xl bg-primary px-4 text-sm font-semibold text-primary-fg",
								children: "Cetak"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "danger",
								onClick: () => {
									if (!window.confirm("Hapus slip ini? Upahnya akan terbuka lagi.")) return;
									const r = data.hapusSlip(s.id);
									if (!r.ok) toast.error(r.error);
									else toast.success("Slip dihapus.");
								},
								children: "Hapus"
							})]
						})]
					}, s.id);
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-2 font-display text-2xl",
			children: "Nota ambil potongan"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "flex flex-col gap-2",
			children: [data.pengambilan.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "text-sm text-muted",
				children: "Belum ada pengambilan."
			}) : null, data.pengambilan.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center justify-between gap-3 rounded-2xl border border-line bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: [
								p.nomor,
								" · ",
								tgl(p.tanggal)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "truncate font-semibold",
							children: [
								namaDari(data.pabrik, p.pabrikId),
								" · ",
								namaDari(data.model, p.modelId)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								p.qty,
								" pcs · ",
								rupiah(p.hargaPerPcs)
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/cetak/ambil/$id",
					params: { id: p.id },
					className: "inline-flex h-11 shrink-0 items-center rounded-xl border border-line px-3 text-sm font-semibold",
					children: "Cetak"
				})]
			}, p.id))]
		})] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TagihanDialog, {
			open: tagihan,
			onClose: () => setTagihan(false)
		})
	] });
}
var SplitComponent = NotaPage;
//#endregion
export { SplitComponent as component };
