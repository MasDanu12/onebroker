import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { B as StatusBadge, D as statusKerja, H as cn, I as Page, L as PageHead, M as Button, N as EmptyState, W as LABEL_STATUS, c as angka, f as rupiah, g as namaDari, o as useBuku, p as tgl, x as qtyMasihJahit, y as qtyBisaBayar } from "./router-D8i6Q1Lc.mjs";
import { t as ContohBanner } from "./contoh-B6Wjm7H1.mjs";
import { t as BayarDialog } from "./forms-uang-BfwMHYUm.mjs";
import { n as BagiDialog, r as HasilDialog } from "./forms-barang-C0_jLVfW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/kerja-Bggo0-nU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FILTER = [
	{
		id: "semua",
		label: "Semua"
	},
	{
		id: "berjalan",
		label: LABEL_STATUS.berjalan
	},
	{
		id: "menunggu-setor",
		label: LABEL_STATUS["menunggu-setor"]
	},
	{
		id: "menunggu-tagih",
		label: LABEL_STATUS["menunggu-tagih"]
	},
	{
		id: "beres",
		label: LABEL_STATUS.beres
	}
];
function KerjaPage() {
	const data = useBuku();
	const [filter, setFilter] = (0, import_react.useState)("semua");
	const [bagi, setBagi] = (0, import_react.useState)(false);
	const [hasil, setHasil] = (0, import_react.useState)(null);
	const [bayar, setBayar] = (0, import_react.useState)(null);
	const rows = (0, import_react.useMemo)(() => {
		return data.pekerjaan.map((k) => {
			return {
				k,
				amb: data.pengambilan.find((p) => p.id === k.pengambilanId),
				status: statusKerja(k)
			};
		}).filter((row) => filter === "semua" || row.status === filter).sort((a, b) => {
			const rank = {
				berjalan: 0,
				"menunggu-setor": 1,
				"menunggu-tagih": 2,
				beres: 3
			};
			return rank[a.status] - rank[b.status] || b.k.tanggalBagi.localeCompare(a.k.tanggalBagi);
		});
	}, [data, filter]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContohBanner, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			title: "Pekerjaan",
			lede: "Potongan yang sudah dipegang penjahit. Catat yang bagus, yang rusak, dan yang sudah disetor.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setBagi(true),
				children: "Bagi potongan"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 flex gap-2 overflow-x-auto pb-1",
			children: FILTER.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setFilter(f.id),
				className: cn("h-10 shrink-0 rounded-full px-3 text-sm font-semibold", filter === f.id ? "bg-fg text-surface" : "border border-line bg-surface"),
				children: f.label
			}, f.id))
		}),
		data.pekerjaan.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			title: "Belum ada pekerjaan",
			body: "Bagi potongan yang sudah diambil ke penjahit, lalu catat hasilnya di sini.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setBagi(true),
				children: "Bagi potongan"
			})
		}) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			title: "Tidak ada di saringan ini",
			body: "Coba saringan lain, atau catat hasil jahitan yang baru selesai."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col gap-3",
			children: rows.map(({ k, amb, status }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-2xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold text-muted",
									children: k.nomor
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "truncate font-display text-2xl",
									children: namaDari(data.penjahit, k.penjahitId)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-muted",
									children: [
										namaDari(data.model, amb?.modelId ?? ""),
										" · ",
										namaDari(data.pabrik, amb?.pabrikId ?? ""),
										" · dibagi ",
										tgl(k.tanggalBagi)
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-3 grid grid-cols-2 gap-2 text-sm sm:grid-cols-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Angka, {
								label: "Dipegang",
								nilai: `${angka(k.qty)} pcs`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Angka, {
								label: "Bagus",
								nilai: angka(k.qtySelesai)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Angka, {
								label: "Rusak",
								nilai: angka(k.qtyRusak)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Angka, {
								label: "Masih dijahit",
								nilai: angka(qtyMasihJahit(k))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Angka, {
								label: "Disetor",
								nilai: angka(k.qtySetor)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Angka, {
								label: "Sudah ditagih",
								nilai: angka(k.qtyTertagih)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Angka, {
								label: "Upah / pcs",
								nilai: rupiah(k.upahPerPcs)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Angka, {
								label: "Upah belum",
								nilai: rupiah(qtyBisaBayar(k) * k.upahPerPcs)
							})
						]
					}),
					k.catatan ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: k.catatan
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "px-3",
							onClick: () => setHasil(k.id),
							children: "Catat hasil"
						}), qtyBisaBayar(k) > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							className: "px-3",
							onClick: () => setBayar(k.penjahitId),
							children: "Bayar upah"
						}) : null]
					})
				]
			}, k.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BagiDialog, {
			open: bagi,
			onClose: () => setBagi(false)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HasilDialog, {
			open: hasil !== null,
			onClose: () => setHasil(null),
			kerjaId: hasil ?? void 0
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BayarDialog, {
			open: bayar !== null,
			onClose: () => setBayar(null),
			penjahitAwal: bayar ?? void 0
		})
	] });
}
function Angka({ label, nilai }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-ink-soft px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-0.5 font-semibold tabular-nums",
			children: nilai
		})]
	});
}
var SplitComponent = KerjaPage;
//#endregion
export { SplitComponent as component };
