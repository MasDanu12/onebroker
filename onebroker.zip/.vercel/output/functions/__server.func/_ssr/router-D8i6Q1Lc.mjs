import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as lazyRouteComponent, b as Link, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, p as useRouterState, v as createFileRoute, x as useRouter, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Settings, c as LayoutDashboard, i as TriangleAlert, l as FileText, n as Wallet, o as Scissors, s as Package, t as X } from "../_libs/lucide-react.mjs";
import { a as DialogPortal, i as DialogOverlay, n as DialogClose, o as DialogTitle, r as DialogContent, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-D8i6Q1Lc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
var LABEL_KAS = {
	modal: "Uang pribadi masuk",
	tarik: "Tarik ke dompet",
	terima_pabrik: "Terima dari pabrik",
	muka_pabrik: "Pabrik bayar duluan",
	bayar_upah: "Bayar upah",
	kasbon_penjahit: "Kasbon penjahit"
};
var LABEL_STATUS = {
	berjalan: "Sedang dijahit",
	"menunggu-setor": "Siap disetor",
	"menunggu-tagih": "Siap ditagih",
	beres: "Beres"
};
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = {
	primary: "bg-primary text-primary-fg",
	pine: "bg-pine text-pine-fg",
	ghost: "bg-transparent text-fg hover:bg-sunken",
	outline: "border border-line bg-surface text-fg hover:bg-ink-soft",
	danger: "bg-transparent text-primary hover:bg-rust-soft"
};
function Button({ className, variant = "primary", type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn("inline-flex h-11 items-center justify-center gap-2 rounded-xl px-4 text-sm font-semibold transition-colors disabled:opacity-50", buttonVariants[variant], className),
		...props
	});
}
var fieldClass = "h-11 w-full rounded-xl border border-line bg-surface px-3 text-base text-fg outline-none focus:border-primary";
function Field({ label, hint, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "mb-3 block",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mb-1.5 block text-sm font-medium",
				children: label
			}),
			children,
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1.5 block text-xs leading-5 text-muted",
				children: hint
			}) : null
		]
	});
}
function TextInput(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		...props,
		className: cn(fieldClass, props.className)
	});
}
function Area(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		...props,
		className: cn("min-h-20 w-full rounded-xl border border-line bg-surface px-3 py-2 text-base text-fg outline-none focus:border-primary", props.className)
	});
}
function Select(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		...props,
		className: cn(fieldClass, props.className)
	});
}
function Modal({ open, onClose, title, children, wide }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-40 bg-fg/40 no-print" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: cn("fixed z-50 flex max-h-[92vh] w-full flex-col overflow-hidden bg-surface shadow-lg", "inset-x-0 bottom-0 rounded-t-2xl md:inset-auto md:left-1/2 md:top-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:rounded-2xl", wide ? "md:max-w-xl" : "md:max-w-md"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3 border-b border-line px-5 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "font-display text-2xl leading-tight",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
					className: "grid size-11 place-items-center rounded-xl text-muted hover:bg-sunken",
					"aria-label": "Tutup",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-y-auto px-5 py-4",
				children
			})]
		})] })
	});
}
var statusClass = {
	berjalan: "bg-pine-soft text-pine",
	"menunggu-setor": "bg-sunken text-fg",
	"menunggu-tagih": "bg-rust-soft text-primary",
	beres: "bg-ink-soft text-muted"
};
function StatusBadge({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex rounded-full px-2.5 py-1 text-xs font-semibold", statusClass[status]),
		children: LABEL_STATUS[status]
	});
}
function StatCard({ label, value, hint, icon, to }) {
	const body = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2 text-sm text-muted",
			children: [icon, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 font-display text-2xl leading-none tabular-nums sm:text-3xl",
			children: value
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: hint
		})
	] });
	const cls = "block rounded-2xl border border-line bg-surface p-4 text-left";
	if (!to) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		className: cls,
		children: body
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to,
		className: cn(cls, "hover:border-primary"),
		children: body
	});
}
function EmptyState({ title, body, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-dashed border-line bg-surface px-5 py-10 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-auto mt-2 max-w-md text-sm leading-6 text-muted",
				children: body
			}),
			action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: action
			}) : null
		]
	});
}
function PageHead({ title, lede, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "mb-5 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl leading-tight",
			children: title
		}), lede ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 max-w-xl text-sm leading-6 text-muted",
			children: lede
		}) : null] }), action]
	});
}
function Page({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto w-full max-w-5xl px-4 py-5 md:px-8 md:py-8",
		children
	});
}
function namaDari(list, id) {
	return list.find((x) => x.id === id)?.nama ?? "—";
}
function sisaPotongan(p, pekerjaan) {
	const bagi = pekerjaan.filter((k) => k.pengambilanId === p.id).reduce((a, k) => a + k.qty, 0);
	return p.qty - bagi;
}
function statusKerja(k) {
	if (k.qtySelesai + k.qtyRusak < k.qty) return "berjalan";
	if (k.qtySetor < k.qtySelesai) return "menunggu-setor";
	if (k.qtyTertagih < k.qtySetor) return "menunggu-tagih";
	return "beres";
}
function qtyMasihJahit(k) {
	return Math.max(0, k.qty - k.qtySelesai - k.qtyRusak);
}
function qtyBisaTagih(k) {
	return Math.max(0, k.qtySetor - k.qtyTertagih);
}
function qtyBisaBayar(k) {
	return Math.max(0, k.qtySelesai - k.qtyTerbayar);
}
function nilaiTagihan(t) {
	return t.items.reduce((a, i) => a + i.qty * i.hargaPerPcs, 0);
}
function nilaiSlip(s) {
	return s.items.reduce((a, i) => a + i.qty * i.upahPerPcs, 0);
}
function masukKas(jenis) {
	return jenis === "modal" || jenis === "terima_pabrik" || jenis === "muka_pabrik";
}
function saldoKas(kas) {
	return kas.reduce((a, k) => a + (masukKas(k.jenis) ? k.jumlah : -k.jumlah), 0);
}
function sisaKasbon(penjahitId, kas, slip) {
	return kas.filter((k) => k.jenis === "kasbon_penjahit" && k.penjahitId === penjahitId).reduce((a, k) => a + k.jumlah, 0) - slip.filter((s) => s.penjahitId === penjahitId).reduce((a, s) => a + s.potongKasbon, 0);
}
function terimaTagihan(tagihanId, kas) {
	return kas.filter((k) => k.tagihanId === tagihanId).reduce((a, k) => a + k.jumlah, 0);
}
function saldoPabrik(d) {
	return d.pabrik.map((p) => {
		const tagih = d.tagihan.filter((t) => t.pabrikId === p.id).reduce((a, t) => a + nilaiTagihan(t), 0);
		const masuk = d.kas.filter((k) => k.pabrikId === p.id && (k.jenis === "terima_pabrik" || k.jenis === "muka_pabrik")).reduce((a, k) => a + k.jumlah, 0);
		return {
			pabrik: p,
			tagih,
			masuk,
			sisa: tagih - masuk
		};
	});
}
function saldoPenjahit(d) {
	return d.penjahit.map((p) => {
		const jobs = d.pekerjaan.filter((k) => k.penjahitId === p.id);
		const upahBelum = jobs.reduce((a, k) => a + qtyBisaBayar(k) * k.upahPerPcs, 0);
		const kasbon = sisaKasbon(p.id, d.kas, d.slip);
		return {
			penjahit: p,
			upahBelum,
			kasbon,
			pcsJalan: jobs.reduce((a, k) => a + qtyMasihJahit(k), 0),
			net: Math.max(0, upahBelum - kasbon)
		};
	});
}
function untungDisetor(d, month) {
	let pendapatan = 0;
	let upah = 0;
	for (const k of d.pekerjaan) {
		if (k.qtySetor <= 0) continue;
		if (month && !k.tanggalSetor.startsWith(month)) continue;
		const amb = d.pengambilan.find((p) => p.id === k.pengambilanId);
		pendapatan += k.qtySetor * (amb?.hargaPerPcs ?? 0);
		upah += k.qtySetor * k.upahPerPcs;
	}
	return {
		pendapatan,
		upah,
		untung: pendapatan - upah
	};
}
function upahMengambang(d) {
	return d.pekerjaan.reduce((a, k) => a + Math.max(0, k.qtySelesai - k.qtySetor) * k.upahPerPcs, 0);
}
function chartModel(d, month) {
	return d.model.map((m) => {
		let pendapatan = 0;
		let upah = 0;
		for (const k of d.pekerjaan) {
			const amb = d.pengambilan.find((p) => p.id === k.pengambilanId);
			if (!amb || amb.modelId !== m.id) continue;
			if (k.qtySetor > 0 && (!month || k.tanggalSetor.startsWith(month))) {
				pendapatan += k.qtySetor * amb.hargaPerPcs;
				upah += k.qtySetor * k.upahPerPcs;
			}
		}
		return {
			nama: m.nama,
			pendapatan,
			upah
		};
	}).filter((row) => row.pendapatan > 0 || row.upah > 0);
}
var BULAN = [
	"Jan",
	"Feb",
	"Mar",
	"Apr",
	"Mei",
	"Jun",
	"Jul",
	"Agu",
	"Sep",
	"Okt",
	"Nov",
	"Des"
];
var BULAN_PANJANG = [
	"Januari",
	"Februari",
	"Maret",
	"April",
	"Mei",
	"Juni",
	"Juli",
	"Agustus",
	"September",
	"Oktober",
	"November",
	"Desember"
];
var HARI = [
	"Minggu",
	"Senin",
	"Selasa",
	"Rabu",
	"Kamis",
	"Jumat",
	"Sabtu"
];
function jakartaToday() {
	return new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Jakarta" }).format(/* @__PURE__ */ new Date());
}
function addDays(iso, n) {
	const [y, m, d] = iso.split("-").map(Number);
	const dt = new Date(Date.UTC(y, m - 1, d));
	dt.setUTCDate(dt.getUTCDate() + n);
	return dt.toISOString().slice(0, 10);
}
function weekday(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	return new Date(Date.UTC(y, m - 1, d)).getUTCDay();
}
function nextPay(hari, today = jakartaToday()) {
	const delta = (hari - weekday(today) + 7) % 7;
	return {
		tanggal: addDays(today, delta),
		hariIni: delta === 0
	};
}
function tgl(iso, panjang = false) {
	if (!iso) return "—";
	const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
	if (!m) return iso;
	const nama = (panjang ? BULAN_PANJANG : BULAN)[Number(m[2]) - 1] ?? m[2];
	return `${Number(m[3])} ${nama} ${m[1]}`;
}
function bulanLabel(ym) {
	const [y, m] = ym.split("-");
	return `${BULAN_PANJANG[Number(m) - 1] ?? m} ${y}`;
}
function angka(n) {
	const v = Math.round(Number.isFinite(n) ? n : 0);
	return (v < 0 ? "−" : "") + Math.abs(v).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}
function rupiah(n) {
	const v = Math.round(Number.isFinite(n) ? n : 0);
	return `${v < 0 ? "−" : ""}Rp ${Math.abs(v).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".")}`;
}
function uid(prefix) {
	return `${prefix}-${Math.random().toString(36).slice(2, 8)}${Date.now().toString(36).slice(-4)}`;
}
function nextNo(prefix, n) {
	return `${prefix}-${String(n).padStart(3, "0")}`;
}
function teks(s, max = 400) {
	return s.trim().slice(0, max);
}
function dataKosong() {
	return {
		profil: {
			nama: "Usaha Makloon",
			pemilik: "",
			telepon: "",
			alamat: "",
			hariBayar: 6
		},
		pabrik: [],
		penjahit: [],
		model: [],
		pengambilan: [],
		pekerjaan: [],
		tagihan: [],
		slip: [],
		kas: [],
		contoh: false,
		seq: {
			amb: 1,
			krj: 1,
			inv: 1,
			slp: 1,
			kas: 1
		}
	};
}
function buatContoh() {
	const t = jakartaToday();
	const ambil = addDays(t, -6);
	const bagi = addDays(t, -5);
	const selesai = addDays(t, -2);
	const bayar = addDays(t, -1);
	return {
		profil: {
			nama: "Makloon Hijab Berkah",
			pemilik: "Ibu pemilik",
			telepon: "0812-0000-1111",
			alamat: "Pekalongan",
			hariBayar: 6
		},
		pabrik: [{
			id: "pb-zahra",
			nama: "Zahra Collection",
			telepon: "0812-1000-0001",
			alamat: "Pekalongan",
			catatan: "Bayar biasanya Sabtu"
		}, {
			id: "pb-melati",
			nama: "Melati Konveksi",
			telepon: "0813-2000-0002",
			alamat: "Bandung",
			catatan: ""
		}],
		penjahit: [
			{
				id: "pj-siti",
				nama: "Bu Siti",
				telepon: "0812-3000-0003",
				alamat: "",
				catatan: ""
			},
			{
				id: "pj-aminah",
				nama: "Bu Aminah",
				telepon: "0812-4000-0004",
				alamat: "",
				catatan: ""
			},
			{
				id: "pj-rina",
				nama: "Mbak Rina",
				telepon: "0812-5000-0005",
				alamat: "",
				catatan: ""
			}
		],
		model: [
			{
				id: "md-segi",
				nama: "Segi empat",
				hargaPabrik: 5e3,
				upahJahit: 3e3
			},
			{
				id: "md-pash",
				nama: "Pashmina",
				hargaPabrik: 6e3,
				upahJahit: 3500
			},
			{
				id: "md-bergo",
				nama: "Bergo",
				hargaPabrik: 4500,
				upahJahit: 2500
			}
		],
		pengambilan: [{
			id: "amb-1",
			nomor: "AMB-001",
			tanggal: ambil,
			pabrikId: "pb-zahra",
			modelId: "md-segi",
			qty: 100,
			hargaPerPcs: 5e3,
			catatan: "Ongkos jahit Rp 5.000, upah penjahit Rp 3.000"
		}, {
			id: "amb-2",
			nomor: "AMB-002",
			tanggal: addDays(t, -4),
			pabrikId: "pb-melati",
			modelId: "md-pash",
			qty: 80,
			hargaPerPcs: 6e3,
			catatan: ""
		}],
		pekerjaan: [
			{
				id: "krj-1",
				nomor: "KRJ-001",
				pengambilanId: "amb-1",
				penjahitId: "pj-siti",
				tanggalBagi: bagi,
				qty: 60,
				upahPerPcs: 3e3,
				qtySelesai: 58,
				qtyRusak: 2,
				tanggalSelesai: selesai,
				qtySetor: 58,
				tanggalSetor: selesai,
				qtyTertagih: 58,
				qtyTerbayar: 58,
				catatan: "2 pcs rusak, tidak ditagih dan tidak diupah"
			},
			{
				id: "krj-2",
				nomor: "KRJ-002",
				pengambilanId: "amb-2",
				penjahitId: "pj-rina",
				tanggalBagi: addDays(t, -3),
				qty: 50,
				upahPerPcs: 3500,
				qtySelesai: 0,
				qtyRusak: 0,
				tanggalSelesai: "",
				qtySetor: 0,
				tanggalSetor: "",
				qtyTertagih: 0,
				qtyTerbayar: 0,
				catatan: ""
			},
			{
				id: "krj-3",
				nomor: "KRJ-003",
				pengambilanId: "amb-2",
				penjahitId: "pj-aminah",
				tanggalBagi: addDays(t, -3),
				qty: 30,
				upahPerPcs: 3500,
				qtySelesai: 30,
				qtyRusak: 0,
				tanggalSelesai: bayar,
				qtySetor: 0,
				tanggalSetor: "",
				qtyTertagih: 0,
				qtyTerbayar: 0,
				catatan: "Sudah jadi, belum disetor ke pabrik"
			}
		],
		tagihan: [{
			id: "inv-1",
			nomor: "INV-001",
			tanggal: selesai,
			pabrikId: "pb-zahra",
			items: [{
				pekerjaanId: "krj-1",
				modelNama: "Segi empat",
				qty: 58,
				hargaPerPcs: 5e3
			}],
			catatan: "2 pcs rusak tidak ditagih"
		}],
		slip: [{
			id: "slp-1",
			nomor: "SLP-001",
			tanggal: bayar,
			penjahitId: "pj-siti",
			items: [{
				pekerjaanId: "krj-1",
				modelNama: "Segi empat",
				qty: 58,
				upahPerPcs: 3e3
			}],
			potongKasbon: 1e5,
			catatan: "Dibayar dari uang pribadi, dipotong kasbon"
		}],
		kas: [
			{
				id: "kas-1",
				nomor: "KAS-001",
				tanggal: bagi,
				jenis: "kasbon_penjahit",
				jumlah: 1e5,
				pabrikId: "",
				penjahitId: "pj-siti",
				tagihanId: "",
				slipId: "",
				catatan: "Bu Siti minta uang dulu"
			},
			{
				id: "kas-2",
				nomor: "KAS-002",
				tanggal: bayar,
				jenis: "muka_pabrik",
				jumlah: 2e5,
				pabrikId: "pb-zahra",
				penjahitId: "",
				tagihanId: "",
				slipId: "",
				catatan: "Zahra transfer duluan"
			},
			{
				id: "kas-3",
				nomor: "KAS-003",
				tanggal: bayar,
				jenis: "bayar_upah",
				jumlah: 74e3,
				pabrikId: "",
				penjahitId: "pj-siti",
				tagihanId: "",
				slipId: "slp-1",
				catatan: "Upah 174.000 dipotong kasbon 100.000"
			}
		],
		contoh: true,
		seq: {
			amb: 3,
			krj: 4,
			inv: 2,
			slp: 2,
			kas: 4
		}
	};
}
function fail(error) {
	return {
		ok: false,
		error
	};
}
function ok(id) {
	return {
		ok: true,
		id
	};
}
function tanggalOk(t) {
	return /^\d{4}-\d{2}-\d{2}$/.test(t);
}
function num(n) {
	if (!Number.isFinite(n)) return 0;
	return Math.round(n);
}
var KEYS = [
	"profil",
	"pabrik",
	"penjahit",
	"model",
	"pengambilan",
	"pekerjaan",
	"tagihan",
	"slip",
	"kas",
	"contoh",
	"seq"
];
function numField(v, fallback = 0) {
	const n = Number(v);
	return Number.isFinite(n) ? Math.round(n) : fallback;
}
function parseData(raw) {
	if (!raw || typeof raw !== "object") return null;
	const wrapped = raw;
	const src = wrapped.state && typeof wrapped.state === "object" ? wrapped.state : raw;
	if (!src || typeof src !== "object") return null;
	const o = src;
	if (!Array.isArray(o.pabrik) || !Array.isArray(o.penjahit) || !Array.isArray(o.pengambilan)) return null;
	if (!Array.isArray(o.pekerjaan) || !Array.isArray(o.tagihan) || !Array.isArray(o.slip) || !Array.isArray(o.kas)) return null;
	if (!o.profil || typeof o.profil !== "object" || !o.seq) return null;
	const kosong = dataKosong();
	const pekerjaan = o.pekerjaan.map((k) => ({
		...k,
		qty: numField(k.qty),
		upahPerPcs: numField(k.upahPerPcs),
		qtySelesai: numField(k.qtySelesai),
		qtyRusak: numField(k.qtyRusak),
		qtySetor: numField(k.qtySetor),
		qtyTertagih: numField(k.qtyTertagih),
		qtyTerbayar: numField(k.qtyTerbayar),
		tanggalSelesai: k.tanggalSelesai ?? "",
		tanggalSetor: k.tanggalSetor ?? "",
		catatan: k.catatan ?? ""
	}));
	return {
		profil: {
			nama: o.profil.nama || kosong.profil.nama,
			pemilik: o.profil.pemilik ?? "",
			telepon: o.profil.telepon ?? "",
			alamat: o.profil.alamat ?? "",
			hariBayar: Number.isFinite(o.profil.hariBayar) ? o.profil.hariBayar : 6
		},
		pabrik: o.pabrik,
		penjahit: o.penjahit,
		model: o.model ?? [],
		pengambilan: o.pengambilan.map((p) => ({
			...p,
			qty: numField(p.qty),
			hargaPerPcs: numField(p.hargaPerPcs),
			catatan: p.catatan ?? ""
		})),
		pekerjaan,
		tagihan: o.tagihan,
		slip: o.slip,
		kas: o.kas,
		contoh: Boolean(o.contoh),
		seq: {
			amb: numField(o.seq.amb, 1),
			krj: numField(o.seq.krj, 1),
			inv: numField(o.seq.inv, 1),
			slp: numField(o.seq.slp, 1),
			kas: numField(o.seq.kas, 1)
		}
	};
}
function ambilData(s) {
	const out = {};
	for (const key of KEYS) Object.assign(out, { [key]: s[key] });
	return out;
}
var useBuku = create()(persist((set, get) => ({
	...buatContoh(),
	ambilPotongan: (input) => {
		const s = get();
		if (!s.pabrik.some((p) => p.id === input.pabrikId)) return fail("Pilih pabrik.");
		if (!s.model.some((m) => m.id === input.modelId)) return fail("Pilih model.");
		const qty = num(input.qty);
		const harga = num(input.hargaPerPcs);
		if (qty < 1) return fail("Qty minimal 1.");
		if (qty > 1e5) return fail("Qty terlalu besar.");
		if (harga < 0 || harga > 1e8) return fail("Harga tidak valid.");
		const tanggal = input.tanggal || jakartaToday();
		if (!tanggalOk(tanggal)) return fail("Tanggal tidak valid.");
		if (input.id) {
			const lama = s.pengambilan.find((p) => p.id === input.id);
			if (!lama) return fail("Pengambilan tidak ditemukan.");
			const bagi = s.pekerjaan.filter((k) => k.pengambilanId === lama.id).reduce((a, k) => a + k.qty, 0);
			if (qty < bagi) return fail(`Qty tidak boleh di bawah yang sudah dibagi (${bagi} pcs).`);
			if (s.pekerjaan.some((k) => k.pengambilanId === lama.id && k.qtyTertagih > 0) && harga !== lama.hargaPerPcs) return fail("Harga sudah dipakai di tagihan, tidak diubah.");
			const adaKerja = bagi > 0;
			set({ pengambilan: s.pengambilan.map((p) => p.id === lama.id ? {
				...p,
				tanggal,
				qty,
				hargaPerPcs: harga,
				catatan: teks(input.catatan),
				pabrikId: adaKerja ? p.pabrikId : input.pabrikId,
				modelId: adaKerja ? p.modelId : input.modelId
			} : p) });
			return ok(lama.id);
		}
		const id = uid("amb");
		set({
			pengambilan: [{
				id,
				nomor: nextNo("AMB", s.seq.amb),
				tanggal,
				pabrikId: input.pabrikId,
				modelId: input.modelId,
				qty,
				hargaPerPcs: harga,
				catatan: teks(input.catatan)
			}, ...s.pengambilan],
			seq: {
				...s.seq,
				amb: s.seq.amb + 1
			}
		});
		return ok(id);
	},
	bagiKerja: (input) => {
		const s = get();
		const amb = s.pengambilan.find((p) => p.id === input.pengambilanId);
		if (!amb) return fail("Pilih potongan yang diambil.");
		if (!s.penjahit.some((p) => p.id === input.penjahitId)) return fail("Pilih penjahit.");
		const qty = num(input.qty);
		const upah = num(input.upahPerPcs);
		const sisa = sisaPotongan(amb, s.pekerjaan);
		if (qty < 1) return fail("Qty minimal 1.");
		if (qty > sisa) return fail(`Sisa yang belum dibagi hanya ${sisa} pcs.`);
		if (upah < 0) return fail("Upah tidak valid.");
		const tanggal = input.tanggal || jakartaToday();
		if (!tanggalOk(tanggal)) return fail("Tanggal tidak valid.");
		const id = uid("krj");
		set({
			pekerjaan: [{
				id,
				nomor: nextNo("KRJ", s.seq.krj),
				pengambilanId: amb.id,
				penjahitId: input.penjahitId,
				tanggalBagi: tanggal,
				qty,
				upahPerPcs: upah,
				qtySelesai: 0,
				qtyRusak: 0,
				tanggalSelesai: "",
				qtySetor: 0,
				tanggalSetor: "",
				qtyTertagih: 0,
				qtyTerbayar: 0,
				catatan: teks(input.catatan)
			}, ...s.pekerjaan],
			seq: {
				...s.seq,
				krj: s.seq.krj + 1
			}
		});
		return ok(id);
	},
	ubahKerja: (id, input) => {
		const s = get();
		const k = s.pekerjaan.find((x) => x.id === id);
		if (!k) return fail("Pekerjaan tidak ditemukan.");
		const amb = s.pengambilan.find((p) => p.id === k.pengambilanId);
		if (!amb) return fail("Potongan asalnya tidak ketemu.");
		if (!s.penjahit.some((p) => p.id === input.penjahitId)) return fail("Pilih penjahit.");
		if (k.qtyTerbayar > 0 && input.penjahitId !== k.penjahitId) return fail("Penjahit tidak bisa diganti karena upahnya sudah masuk slip.");
		const qty = num(input.qty);
		const upah = num(input.upahPerPcs);
		const qtySelesai = num(input.qtySelesai);
		const qtyRusak = num(input.qtyRusak);
		const qtySetor = num(input.qtySetor);
		if (qty < 1) return fail("Qty minimal 1.");
		const lain = s.pekerjaan.filter((x) => x.pengambilanId === amb.id && x.id !== k.id).reduce((a, x) => a + x.qty, 0);
		if (lain + qty > amb.qty) return fail(`Maksimal ${amb.qty - lain} pcs dari potongan ini.`);
		if (qtySelesai < 0 || qtyRusak < 0 || qtySetor < 0) return fail("Angka tidak boleh minus.");
		if (qtySelesai + qtyRusak > qty) return fail("Bagus + rusak tidak boleh lebih dari qty yang dipegang.");
		if (qtySetor > qtySelesai) return fail("Yang disetor tidak boleh lebih dari yang bagus.");
		if (qtySetor < k.qtyTertagih) return fail(`Sudah ditagih ${k.qtyTertagih} pcs. Setoran tidak boleh di bawah itu.`);
		if (qtySelesai < k.qtyTerbayar) return fail(`Sudah dibayar ${k.qtyTerbayar} pcs. Hasil bagus tidak boleh di bawah itu.`);
		if (k.qtyTerbayar > 0 && upah !== k.upahPerPcs) return fail("Upah sudah masuk slip, tidak diubah.");
		if (!tanggalOk(input.tanggalBagi)) return fail("Tanggal bagi tidak valid.");
		const tanggalSelesai = qtySelesai + qtyRusak > 0 ? input.tanggalSelesai || jakartaToday() : "";
		const tanggalSetor = qtySetor > 0 ? input.tanggalSetor || jakartaToday() : "";
		if (tanggalSelesai && !tanggalOk(tanggalSelesai)) return fail("Tanggal selesai tidak valid.");
		if (tanggalSetor && !tanggalOk(tanggalSetor)) return fail("Tanggal setor tidak valid.");
		set({ pekerjaan: s.pekerjaan.map((x) => x.id === id ? {
			...x,
			penjahitId: input.penjahitId,
			tanggalBagi: input.tanggalBagi,
			qty,
			upahPerPcs: upah,
			qtySelesai,
			qtyRusak,
			tanggalSelesai,
			qtySetor,
			tanggalSetor,
			catatan: teks(input.catatan)
		} : x) });
		return ok(id);
	},
	hapusPengambilan: (id) => {
		const s = get();
		if (s.pekerjaan.some((k) => k.pengambilanId === id)) return fail("Sudah dibagi ke penjahit. Hapus pekerjaannya dulu.");
		set({ pengambilan: s.pengambilan.filter((p) => p.id !== id) });
		return ok();
	},
	hapusKerja: (id) => {
		const s = get();
		const k = s.pekerjaan.find((x) => x.id === id);
		if (!k) return fail("Pekerjaan tidak ditemukan.");
		if (k.qtyTertagih > 0) return fail("Sudah masuk tagihan. Hapus tagihannya dulu.");
		if (k.qtyTerbayar > 0) return fail("Sudah masuk slip upah. Hapus slipnya dulu.");
		set({ pekerjaan: s.pekerjaan.filter((x) => x.id !== id) });
		return ok();
	},
	buatTagihan: (input) => {
		const s = get();
		if (!s.pabrik.some((p) => p.id === input.pabrikId)) return fail("Pilih pabrik.");
		const tanggal = input.tanggal || jakartaToday();
		if (!tanggalOk(tanggal)) return fail("Tanggal tidak valid.");
		const lines = input.lines.map((l) => ({
			...l,
			qty: num(l.qty)
		})).filter((l) => l.qty > 0);
		if (lines.length === 0) return fail("Pilih barang yang ditagih.");
		const items = [];
		for (const line of lines) {
			const k = s.pekerjaan.find((x) => x.id === line.pekerjaanId);
			if (!k) return fail("Pekerjaan tidak ditemukan.");
			const amb = s.pengambilan.find((p) => p.id === k.pengambilanId);
			if (!amb || amb.pabrikId !== input.pabrikId) return fail("Pekerjaan ini bukan milik pabrik yang dipilih.");
			if (line.qty > qtyBisaTagih(k)) return fail(`${k.nomor} hanya bisa ditagih ${qtyBisaTagih(k)} pcs.`);
			const model = s.model.find((m) => m.id === amb.modelId);
			items.push({
				pekerjaanId: k.id,
				modelNama: model?.nama ?? "Potongan",
				qty: line.qty,
				hargaPerPcs: amb.hargaPerPcs
			});
		}
		const id = uid("inv");
		let pekerjaan = s.pekerjaan;
		for (const item of items) pekerjaan = pekerjaan.map((k) => k.id === item.pekerjaanId ? {
			...k,
			qtyTertagih: k.qtyTertagih + item.qty
		} : k);
		set({
			pekerjaan,
			tagihan: [{
				id,
				nomor: nextNo("INV", s.seq.inv),
				tanggal,
				pabrikId: input.pabrikId,
				items,
				catatan: teks(input.catatan)
			}, ...s.tagihan],
			seq: {
				...s.seq,
				inv: s.seq.inv + 1
			}
		});
		return ok(id);
	},
	hapusTagihan: (id) => {
		const s = get();
		const t = s.tagihan.find((x) => x.id === id);
		if (!t) return fail("Tagihan tidak ditemukan.");
		if (s.kas.some((k) => k.tagihanId === id)) return fail("Masih ada uang masuk yang dikaitkan ke tagihan ini. Hapus pembayaran itu dulu.");
		let pekerjaan = s.pekerjaan;
		for (const item of t.items) pekerjaan = pekerjaan.map((k) => k.id === item.pekerjaanId ? {
			...k,
			qtyTertagih: Math.max(0, k.qtyTertagih - item.qty)
		} : k);
		set({
			pekerjaan,
			tagihan: s.tagihan.filter((x) => x.id !== id)
		});
		return ok();
	},
	terimaPabrik: (input) => {
		const s = get();
		if (!s.pabrik.some((p) => p.id === input.pabrikId)) return fail("Pilih pabrik.");
		const jumlah = num(input.jumlah);
		if (jumlah < 1) return fail("Jumlah minimal Rp 1.");
		if (jumlah > 0xe8d4a51000) return fail("Jumlah terlalu besar.");
		const tanggal = input.tanggal || jakartaToday();
		if (!tanggalOk(tanggal)) return fail("Tanggal tidak valid.");
		let tagihanId = "";
		if (input.jenis === "terima_pabrik" && input.tagihanId) {
			const t = s.tagihan.find((x) => x.id === input.tagihanId);
			if (!t || t.pabrikId !== input.pabrikId) return fail("Tagihan tidak cocok dengan pabrik.");
			tagihanId = t.id;
		}
		const id = uid("kas");
		set({
			kas: [{
				id,
				nomor: nextNo("KAS", s.seq.kas),
				tanggal,
				jenis: input.jenis,
				jumlah,
				pabrikId: input.pabrikId,
				penjahitId: "",
				tagihanId,
				slipId: "",
				catatan: teks(input.catatan)
			}, ...s.kas],
			seq: {
				...s.seq,
				kas: s.seq.kas + 1
			}
		});
		return ok(id);
	},
	bayarUpah: (input) => {
		const s = get();
		if (!s.penjahit.some((p) => p.id === input.penjahitId)) return fail("Pilih penjahit.");
		const tanggal = input.tanggal || jakartaToday();
		if (!tanggalOk(tanggal)) return fail("Tanggal tidak valid.");
		const lines = input.lines.map((l) => ({
			...l,
			qty: num(l.qty)
		})).filter((l) => l.qty > 0);
		if (lines.length === 0) return fail("Pilih upah yang dibayar.");
		const items = [];
		for (const line of lines) {
			const k = s.pekerjaan.find((x) => x.id === line.pekerjaanId);
			if (!k || k.penjahitId !== input.penjahitId) return fail("Ada pekerjaan yang bukan milik penjahit ini.");
			if (line.qty > qtyBisaBayar(k)) return fail(`${k.nomor} hanya bisa dibayar ${qtyBisaBayar(k)} pcs.`);
			const amb = s.pengambilan.find((p) => p.id === k.pengambilanId);
			const model = s.model.find((m) => m.id === amb?.modelId);
			items.push({
				pekerjaanId: k.id,
				modelNama: model?.nama ?? "Potongan",
				qty: line.qty,
				upahPerPcs: k.upahPerPcs
			});
		}
		const bruto = items.reduce((a, i) => a + i.qty * i.upahPerPcs, 0);
		const potong = num(input.potongKasbon);
		const kasbon = sisaKasbon(input.penjahitId, s.kas, s.slip);
		if (potong < 0) return fail("Potongan kasbon tidak valid.");
		if (potong > kasbon) return fail(`Sisa kasbon hanya Rp ${kasbon.toLocaleString("id-ID")}.`);
		if (potong > bruto) return fail("Potongan kasbon tidak boleh lebih dari upah.");
		const tunai = bruto - potong;
		const slipId = uid("slp");
		let pekerjaan = s.pekerjaan;
		for (const item of items) pekerjaan = pekerjaan.map((k) => k.id === item.pekerjaanId ? {
			...k,
			qtyTerbayar: k.qtyTerbayar + item.qty
		} : k);
		const kas = [...s.kas];
		let seqKas = s.seq.kas;
		if (tunai > 0) {
			kas.unshift({
				id: uid("kas"),
				nomor: nextNo("KAS", seqKas),
				tanggal,
				jenis: "bayar_upah",
				jumlah: tunai,
				pabrikId: "",
				penjahitId: input.penjahitId,
				tagihanId: "",
				slipId,
				catatan: teks(input.catatan) || "Bayar upah"
			});
			seqKas += 1;
		}
		set({
			pekerjaan,
			kas,
			slip: [{
				id: slipId,
				nomor: nextNo("SLP", s.seq.slp),
				tanggal,
				penjahitId: input.penjahitId,
				items,
				potongKasbon: potong,
				catatan: teks(input.catatan)
			}, ...s.slip],
			seq: {
				...s.seq,
				slp: s.seq.slp + 1,
				kas: seqKas
			}
		});
		return ok(slipId);
	},
	kasihKasbon: (input) => {
		const s = get();
		if (!s.penjahit.some((p) => p.id === input.penjahitId)) return fail("Pilih penjahit.");
		const jumlah = num(input.jumlah);
		if (jumlah < 1) return fail("Jumlah minimal Rp 1.");
		const tanggal = input.tanggal || jakartaToday();
		if (!tanggalOk(tanggal)) return fail("Tanggal tidak valid.");
		const id = uid("kas");
		set({
			kas: [{
				id,
				nomor: nextNo("KAS", s.seq.kas),
				tanggal,
				jenis: "kasbon_penjahit",
				jumlah,
				pabrikId: "",
				penjahitId: input.penjahitId,
				tagihanId: "",
				slipId: "",
				catatan: teks(input.catatan)
			}, ...s.kas],
			seq: {
				...s.seq,
				kas: s.seq.kas + 1
			}
		});
		return ok(id);
	},
	uangPribadi: (input) => {
		const s = get();
		const jumlah = num(input.jumlah);
		if (jumlah < 1) return fail("Jumlah minimal Rp 1.");
		const tanggal = input.tanggal || jakartaToday();
		if (!tanggalOk(tanggal)) return fail("Tanggal tidak valid.");
		const id = uid("kas");
		set({
			kas: [{
				id,
				nomor: nextNo("KAS", s.seq.kas),
				tanggal,
				jenis: input.jenis,
				jumlah,
				pabrikId: "",
				penjahitId: "",
				tagihanId: "",
				slipId: "",
				catatan: teks(input.catatan)
			}, ...s.kas],
			seq: {
				...s.seq,
				kas: s.seq.kas + 1
			}
		});
		return ok(id);
	},
	hapusKas: (id) => {
		const s = get();
		const row = s.kas.find((k) => k.id === id);
		if (!row) return fail("Catatan kas tidak ditemukan.");
		if (row.slipId) return fail("Ini bagian dari slip upah. Hapus slipnya supaya upahnya terbuka lagi.");
		if (row.jenis === "kasbon_penjahit") {
			if (sisaKasbon(row.penjahitId, s.kas.filter((k) => k.id !== id), s.slip) < 0) return fail("Kasbon ini sudah dipotong di slip upah.");
		}
		set({ kas: s.kas.filter((k) => k.id !== id) });
		return ok();
	},
	hapusSlip: (id) => {
		const s = get();
		const slip = s.slip.find((x) => x.id === id);
		if (!slip) return fail("Slip tidak ditemukan.");
		let pekerjaan = s.pekerjaan;
		for (const item of slip.items) pekerjaan = pekerjaan.map((k) => k.id === item.pekerjaanId ? {
			...k,
			qtyTerbayar: Math.max(0, k.qtyTerbayar - item.qty)
		} : k);
		set({
			pekerjaan,
			slip: s.slip.filter((x) => x.id !== id),
			kas: s.kas.filter((k) => k.slipId !== id)
		});
		return ok();
	},
	simpanPabrik: (input) => {
		const nama = teks(input.nama, 80);
		if (!nama) return fail("Nama pabrik wajib diisi.");
		const s = get();
		if (input.id) {
			if (!s.pabrik.some((p) => p.id === input.id)) return fail("Pabrik tidak ditemukan.");
			set({ pabrik: s.pabrik.map((p) => p.id === input.id ? {
				...p,
				nama,
				telepon: teks(input.telepon, 40),
				alamat: teks(input.alamat, 160),
				catatan: teks(input.catatan)
			} : p) });
			return ok(input.id);
		}
		const id = uid("pb");
		set({ pabrik: [{
			id,
			nama,
			telepon: teks(input.telepon, 40),
			alamat: teks(input.alamat, 160),
			catatan: teks(input.catatan)
		}, ...s.pabrik] });
		return ok(id);
	},
	simpanPenjahit: (input) => {
		const nama = teks(input.nama, 80);
		if (!nama) return fail("Nama penjahit wajib diisi.");
		const s = get();
		if (input.id) {
			if (!s.penjahit.some((p) => p.id === input.id)) return fail("Penjahit tidak ditemukan.");
			set({ penjahit: s.penjahit.map((p) => p.id === input.id ? {
				...p,
				nama,
				telepon: teks(input.telepon, 40),
				alamat: teks(input.alamat, 160),
				catatan: teks(input.catatan)
			} : p) });
			return ok(input.id);
		}
		const id = uid("pj");
		set({ penjahit: [{
			id,
			nama,
			telepon: teks(input.telepon, 40),
			alamat: teks(input.alamat, 160),
			catatan: teks(input.catatan)
		}, ...s.penjahit] });
		return ok(id);
	},
	simpanModel: (input) => {
		const nama = teks(input.nama, 80);
		if (!nama) return fail("Nama model wajib diisi.");
		const harga = num(input.hargaPabrik);
		const upah = num(input.upahJahit);
		if (harga < 0 || upah < 0) return fail("Harga atau upah tidak valid.");
		const s = get();
		if (input.id) {
			if (!s.model.some((m) => m.id === input.id)) return fail("Model tidak ditemukan.");
			set({ model: s.model.map((m) => m.id === input.id ? {
				...m,
				nama,
				hargaPabrik: harga,
				upahJahit: upah
			} : m) });
			return ok(input.id);
		}
		const id = uid("md");
		set({ model: [...s.model, {
			id,
			nama,
			hargaPabrik: harga,
			upahJahit: upah
		}] });
		return ok(id);
	},
	hapusPabrik: (id) => {
		const s = get();
		if (s.pengambilan.some((p) => p.pabrikId === id) || s.kas.some((k) => k.pabrikId === id)) return fail("Pabrik masih punya pengambilan atau uang. Tidak bisa dihapus.");
		set({ pabrik: s.pabrik.filter((p) => p.id !== id) });
		return ok();
	},
	hapusPenjahit: (id) => {
		const s = get();
		if (s.pekerjaan.some((k) => k.penjahitId === id) || s.slip.some((sl) => sl.penjahitId === id) || s.kas.some((k) => k.penjahitId === id)) return fail("Penjahit masih punya pekerjaan, slip, atau kasbon.");
		set({ penjahit: s.penjahit.filter((p) => p.id !== id) });
		return ok();
	},
	hapusModel: (id) => {
		const s = get();
		if (s.pengambilan.some((p) => p.modelId === id)) return fail("Model masih dipakai di pengambilan.");
		set({ model: s.model.filter((m) => m.id !== id) });
		return ok();
	},
	simpanProfil: (profil) => {
		const nama = teks(profil.nama, 80);
		if (!nama) return fail("Nama usaha wajib diisi.");
		const hari = num(profil.hariBayar);
		if (hari < 0 || hari > 6) return fail("Hari bayar tidak valid.");
		set({ profil: {
			nama,
			pemilik: teks(profil.pemilik, 80),
			telepon: teks(profil.telepon, 40),
			alamat: teks(profil.alamat, 160),
			hariBayar: hari
		} });
		return ok();
	},
	kosongkan: () => set(dataKosong()),
	muatContoh: () => set(buatContoh()),
	pakaiData: () => set({ contoh: false }),
	impor: (raw) => {
		const data = parseData(raw);
		if (!data) return fail("File ini bukan cadangan Buku Makloon.");
		set(data);
		return ok();
	}
}), {
	name: "buku-makloon-v1",
	skipHydration: true,
	version: 1,
	partialize: (s) => {
		const out = {};
		for (const key of KEYS) out[key] = s[key];
		return out;
	}
}));
var NAV = [
	{
		to: "/",
		label: "Beranda",
		icon: LayoutDashboard,
		exact: true
	},
	{
		to: "/potongan",
		label: "Potong",
		icon: Package,
		exact: false
	},
	{
		to: "/kerja",
		label: "Kerja",
		icon: Scissors,
		exact: false
	},
	{
		to: "/kas",
		label: "Kas",
		icon: Wallet,
		exact: false
	},
	{
		to: "/nota",
		label: "Nota",
		icon: FileText,
		exact: false
	}
];
function useReady() {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let live = true;
		const finish = () => {
			if (live) setReady(true);
		};
		const unsub = useBuku.persist.onFinishHydration(finish);
		Promise.resolve(useBuku.persist.rehydrate()).then(finish, finish);
		return () => {
			live = false;
			unsub();
		};
	}, []);
	return ready;
}
function AppShell({ children }) {
	const ready = useReady();
	const path = useRouterState({ select: (s) => s.location.pathname });
	const nama = useBuku((s) => s.profil.nama);
	const cetak = path.startsWith("/cetak");
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-screen place-items-center bg-bg px-6 text-center text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-3xl",
			children: "Buku Makloon"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "Membuka catatan…"
		})] })
	});
	if (cetak) {
		const back = path.includes("/ambil/") ? "/potongan" : "/nota";
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-h-screen bg-bg text-fg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "no-print sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-line bg-surface px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: back,
					className: "inline-flex h-11 items-center rounded-xl px-3 text-sm font-semibold text-pine",
					children: "Kembali"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => window.print(),
					className: "inline-flex h-11 items-center rounded-xl bg-primary px-4 text-sm font-semibold text-primary-fg",
					children: "Cetak / simpan PDF"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-4 py-6 print:p-0",
				children
			})]
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "no-print fixed inset-y-0 left-0 z-20 hidden w-60 flex-col border-r border-line bg-surface md:flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-b border-line px-5 py-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl leading-none",
						children: "Buku Makloon"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 truncate text-sm text-muted",
						children: nama
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "flex flex-1 flex-col gap-1 p-3",
					children: [NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
						...item,
						path
					}, item.to)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
						to: "/data",
						label: "Data usaha",
						icon: Settings,
						exact: false,
						path
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "no-print sticky top-0 z-20 flex items-center justify-between border-b border-line bg-bg px-4 py-3 md:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl leading-none",
					children: "Buku Makloon"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-52 truncate text-xs text-muted",
					children: nama
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/data",
					"aria-label": "Data usaha",
					className: "grid size-11 place-items-center rounded-xl border border-line bg-surface",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-5" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "pb-28 md:pb-10 md:pl-60",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "dock no-print fixed inset-x-0 bottom-0 z-20 border-t border-line bg-surface md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid grid-cols-5",
					children: NAV.map((item) => {
						const on = item.exact ? path === item.to : path.startsWith(item.to);
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							className: cn("flex h-16 flex-col items-center justify-center gap-1 text-xs font-semibold", on ? "text-primary" : "text-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), item.label]
						}) }, item.to);
					})
				})
			})
		]
	});
}
function NavLink({ to, label, icon: Icon, exact, path }) {
	const on = exact ? path === to : path.startsWith(to);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: cn("flex h-11 items-center gap-3 rounded-xl px-3 text-sm font-semibold", on ? "bg-fg text-surface" : "text-fg hover:bg-ink-soft"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), label]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var styles_default = "/assets/styles-Bsu3_oyg.css";
var Route$9 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Buku Makloon" },
			{
				name: "theme-color",
				content: "#8d3d32"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,560;9..144,650&family=Outfit:wght@400;500;600;700&display=swap"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "id",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, { position: "top-center" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$8 = () => import("./routes-bQMAL4zH.mjs");
var Route$8 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./data-BjlSS6Ee.mjs");
var Route$7 = createFileRoute("/data")({
	head: () => ({ meta: [{ title: "Data usaha · Buku Makloon" }] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./kas-C6x8GyXl.mjs");
var Route$6 = createFileRoute("/kas")({
	head: () => ({ meta: [{ title: "Kas · Buku Makloon" }] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./kerja-Bggo0-nU.mjs");
var Route$5 = createFileRoute("/kerja")({
	head: () => ({ meta: [{ title: "Pekerjaan · Buku Makloon" }] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./nota-CD700MFV.mjs");
var Route$4 = createFileRoute("/nota")({
	head: () => ({ meta: [{ title: "Nota · Buku Makloon" }] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./potongan-BKSn1SSC.mjs");
var Route$3 = createFileRoute("/potongan")({
	head: () => ({ meta: [{ title: "Potongan · Buku Makloon" }] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./cetak.ambil._id-4ZPQn8jT.mjs");
var Route$2 = createFileRoute("/cetak/ambil/$id")({
	head: () => ({ meta: [{ title: "Nota ambil · Buku Makloon" }] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./cetak.slip._id-GudAunkn.mjs");
var Route$1 = createFileRoute("/cetak/slip/$id")({
	head: () => ({ meta: [{ title: "Slip upah · Buku Makloon" }] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./cetak.tagihan._id-qRjVrN7w.mjs");
var Route = createFileRoute("/cetak/tagihan/$id")({
	head: () => ({ meta: [{ title: "Tagihan · Buku Makloon" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var rootRouteChildren = {
	IndexRoute: Route$8.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$9
	}),
	DataRoute: Route$7.update({
		id: "/data",
		path: "/data",
		getParentRoute: () => Route$9
	}),
	KasRoute: Route$6.update({
		id: "/kas",
		path: "/kas",
		getParentRoute: () => Route$9
	}),
	KerjaRoute: Route$5.update({
		id: "/kerja",
		path: "/kerja",
		getParentRoute: () => Route$9
	}),
	NotaRoute: Route$4.update({
		id: "/nota",
		path: "/nota",
		getParentRoute: () => Route$9
	}),
	PotonganRoute: Route$3.update({
		id: "/potongan",
		path: "/potongan",
		getParentRoute: () => Route$9
	}),
	CetakAmbilIdRoute: Route$2.update({
		id: "/cetak/ambil/$id",
		path: "/cetak/ambil/$id",
		getParentRoute: () => Route$9
	}),
	CetakSlipIdRoute: Route$1.update({
		id: "/cetak/slip/$id",
		path: "/cetak/slip/$id",
		getParentRoute: () => Route$9
	}),
	CetakTagihanIdRoute: Route.update({
		id: "/cetak/tagihan/$id",
		path: "/cetak/tagihan/$id",
		getParentRoute: () => Route$9
	})
};
var routeTree = Route$9._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { upahMengambang as A, StatusBadge as B, saldoPabrik as C, statusKerja as D, sisaPotongan as E, Modal as F, cn as H, Page as I, PageHead as L, Button as M, EmptyState as N, terimaTagihan as O, Field as P, Select as R, saldoKas as S, sisaKasbon as T, LABEL_KAS as U, TextInput as V, LABEL_STATUS as W, nilaiSlip as _, ambilData as a, qtyBisaTagih as b, angka as c, nextPay as d, rupiah as f, namaDari as g, masukKas as h, Route$2 as i, Area as j, untungDisetor as k, bulanLabel as l, chartModel as m, Route as n, useBuku as o, tgl as p, Route$1 as r, HARI as s, router_exports as t, jakartaToday as u, nilaiTagihan as v, saldoPenjahit as w, qtyMasihJahit as x, qtyBisaBayar as y, StatCard as z };
