import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { F as Modal, I as Page, L as PageHead, M as Button, P as Field, V as TextInput, a as ambilData, f as rupiah, j as Area, o as useBuku, s as HARI, u as jakartaToday } from "./router-D8i6Q1Lc.mjs";
import { t as ContohBanner } from "./contoh-B6Wjm7H1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/data-BjlSS6Ee.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function say(result, sukses) {
	if (!result.ok) {
		toast.error(result.error ?? "Gagal menyimpan.");
		return false;
	}
	toast.success(sukses);
	return true;
}
function ProfilDialog({ open, onClose }) {
	const profil = useBuku((s) => s.profil);
	const simpanProfil = useBuku((s) => s.simpanProfil);
	const [nama, setNama] = (0, import_react.useState)(profil.nama);
	const [pemilik, setPemilik] = (0, import_react.useState)(profil.pemilik);
	const [telepon, setTelepon] = (0, import_react.useState)(profil.telepon);
	const [alamat, setAlamat] = (0, import_react.useState)(profil.alamat);
	const [hari, setHari] = (0, import_react.useState)(String(profil.hariBayar));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onClose,
		title: "Profil usaha",
		children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: (e) => {
				e.preventDefault();
				if (say(simpanProfil({
					nama,
					pemilik,
					telepon,
					alamat,
					hariBayar: Number(hari)
				}), "Profil disimpan. Nama ini yang tercetak di nota.")) onClose();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Nama usaha",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: nama,
						onChange: (e) => setNama(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Nama pemilik",
					hint: "Muncul di kolom tanda tangan.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: pemilik,
						onChange: (e) => setPemilik(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Telepon",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: telepon,
						onChange: (e) => setTelepon(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Alamat",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
						value: alamat,
						onChange: (e) => setAlamat(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Hari bayar upah",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "h-11 w-full rounded-xl border border-line bg-surface px-3",
						value: hari,
						onChange: (e) => setHari(e.target.value),
						children: HARI.map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: i,
							children: h
						}, h))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: "Simpan"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: onClose,
						children: "Batal"
					})]
				})
			]
		}) : null
	});
}
function PabrikDialog({ open, onClose, awal }) {
	const simpan = useBuku((s) => s.simpanPabrik);
	const hapus = useBuku((s) => s.hapusPabrik);
	const [nama, setNama] = (0, import_react.useState)(awal?.nama ?? "");
	const [telepon, setTelepon] = (0, import_react.useState)(awal?.telepon ?? "");
	const [alamat, setAlamat] = (0, import_react.useState)(awal?.alamat ?? "");
	const [catatan, setCatatan] = (0, import_react.useState)(awal?.catatan ?? "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onClose,
		title: awal ? "Ubah pabrik" : "Tambah pabrik",
		children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: (e) => {
				e.preventDefault();
				if (say(simpan({
					id: awal?.id,
					nama,
					telepon,
					alamat,
					catatan
				}), "Pabrik disimpan.")) onClose();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Nama",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: nama,
						onChange: (e) => setNama(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Telepon",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: telepon,
						onChange: (e) => setTelepon(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Alamat",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: alamat,
						onChange: (e) => setAlamat(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Catatan",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
						value: catatan,
						onChange: (e) => setCatatan(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: "Simpan"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: onClose,
							children: "Batal"
						}),
						awal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "danger",
							onClick: () => {
								if (!window.confirm("Hapus pabrik ini?")) return;
								if (say(hapus(awal.id), "Pabrik dihapus.")) onClose();
							},
							children: "Hapus"
						}) : null
					]
				})
			]
		}) : null
	});
}
function PenjahitDialog({ open, onClose, awal }) {
	const simpan = useBuku((s) => s.simpanPenjahit);
	const hapus = useBuku((s) => s.hapusPenjahit);
	const [nama, setNama] = (0, import_react.useState)(awal?.nama ?? "");
	const [telepon, setTelepon] = (0, import_react.useState)(awal?.telepon ?? "");
	const [alamat, setAlamat] = (0, import_react.useState)(awal?.alamat ?? "");
	const [catatan, setCatatan] = (0, import_react.useState)(awal?.catatan ?? "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onClose,
		title: awal ? "Ubah penjahit" : "Tambah penjahit",
		children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: (e) => {
				e.preventDefault();
				if (say(simpan({
					id: awal?.id,
					nama,
					telepon,
					alamat,
					catatan
				}), "Penjahit disimpan.")) onClose();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Nama",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: nama,
						onChange: (e) => setNama(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Telepon",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: telepon,
						onChange: (e) => setTelepon(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Alamat",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: alamat,
						onChange: (e) => setAlamat(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Catatan",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
						value: catatan,
						onChange: (e) => setCatatan(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: "Simpan"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: onClose,
							children: "Batal"
						}),
						awal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "danger",
							onClick: () => {
								if (!window.confirm("Hapus penjahit ini?")) return;
								if (say(hapus(awal.id), "Penjahit dihapus.")) onClose();
							},
							children: "Hapus"
						}) : null
					]
				})
			]
		}) : null
	});
}
function ModelDialog({ open, onClose, awal }) {
	const simpan = useBuku((s) => s.simpanModel);
	const hapus = useBuku((s) => s.hapusModel);
	const [nama, setNama] = (0, import_react.useState)(awal?.nama ?? "");
	const [harga, setHarga] = (0, import_react.useState)(awal ? String(awal.hargaPabrik) : "");
	const [upah, setUpah] = (0, import_react.useState)(awal ? String(awal.upahJahit) : "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onClose,
		title: awal ? "Ubah model" : "Tambah model",
		children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: (e) => {
				e.preventDefault();
				if (say(simpan({
					id: awal?.id,
					nama,
					hargaPabrik: Number(harga.replace(/\D/g, "")),
					upahJahit: Number(upah.replace(/\D/g, ""))
				}), "Model disimpan.")) onClose();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Nama model",
					hint: "Contoh: segi empat, pashmina, bergo.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: nama,
						onChange: (e) => setNama(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Ongkos dari pabrik per pcs",
					hint: "Dipakai sebagai isi otomatis saat ambil potongan. Order lama tidak berubah.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						inputMode: "numeric",
						value: harga,
						onChange: (e) => setHarga(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Upah penjahit per pcs",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						inputMode: "numeric",
						value: upah,
						onChange: (e) => setUpah(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: "Simpan"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: onClose,
							children: "Batal"
						}),
						awal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "danger",
							onClick: () => {
								if (!window.confirm("Hapus model ini?")) return;
								if (say(hapus(awal.id), "Model dihapus.")) onClose();
							},
							children: "Hapus"
						}) : null
					]
				})
			]
		}) : null
	});
}
function DataPage() {
	const data = useBuku();
	const [profil, setProfil] = (0, import_react.useState)(false);
	const [pabrik, setPabrik] = (0, import_react.useState)(void 0);
	const [penjahit, setPenjahit] = (0, import_react.useState)(void 0);
	const [model, setModel] = (0, import_react.useState)(void 0);
	function unduh() {
		const blob = new Blob([JSON.stringify(ambilData(data), null, 2)], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = `buku-makloon-${jakartaToday()}.json`;
		a.click();
		URL.revokeObjectURL(url);
		toast.success("Cadangan terunduh.");
	}
	function unggah(file) {
		const reader = new FileReader();
		reader.onload = () => {
			try {
				const json = JSON.parse(String(reader.result));
				const r = data.impor(json);
				if (!r.ok) toast.error(r.error);
				else toast.success("Cadangan dimuat.");
			} catch {
				toast.error("File tidak bisa dibaca.");
			}
		};
		reader.readAsText(file);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContohBanner, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			title: "Data usaha",
			lede: "Catatan tersimpan di peramban ini. Unduh cadangan supaya aman kalau ganti HP.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: () => setProfil(true),
				children: "Ubah profil"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "mb-4 rounded-2xl border border-line bg-surface p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: data.profil.nama
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						data.profil.pemilik,
						data.profil.telepon,
						data.profil.alamat
					].filter(Boolean).join(" · ") || "Lengkapi profil supaya nota rapi."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm",
					children: ["Hari bayar: ", HARI[data.profil.hariBayar] ?? "Sabtu"]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Blok, {
			title: "Pabrik",
			onAdd: () => setPabrik(null),
			children: data.pabrik.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Baris, {
				judul: p.nama,
				sub: [p.telepon, p.alamat].filter(Boolean).join(" · "),
				onClick: () => setPabrik(p)
			}, p.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Blok, {
			title: "Penjahit",
			onAdd: () => setPenjahit(null),
			children: data.penjahit.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Baris, {
				judul: p.nama,
				sub: p.telepon,
				onClick: () => setPenjahit(p)
			}, p.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Blok, {
			title: "Model & ongkos baku",
			onAdd: () => setModel(null),
			children: data.model.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Baris, {
				judul: m.nama,
				sub: `Pabrik ${rupiah(m.hargaPabrik)} · upah ${rupiah(m.upahJahit)}`,
				onClick: () => setModel(m)
			}, m.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6 rounded-2xl border border-line bg-surface p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Cadangan"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm leading-6 text-muted",
					children: "Data tidak ikut akun. Simpan file JSON, lalu muat lagi di HP atau browser lain."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: unduh,
						children: "Unduh cadangan"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "inline-flex h-11 cursor-pointer items-center rounded-xl border border-line bg-surface px-4 text-sm font-semibold",
						children: ["Muat cadangan", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "application/json,.json",
							className: "sr-only",
							onChange: (e) => {
								const file = e.target.files?.[0];
								if (file) unggah(file);
								e.target.value = "";
							}
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap gap-2 border-t border-line pt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "danger",
						onClick: () => {
							if (window.confirm("Kosongkan seluruh buku? Unduh cadangan dulu kalau masih perlu.")) data.kosongkan();
						},
						children: "Kosongkan buku"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: () => {
							if (window.confirm("Ganti isi buku dengan data contoh?")) data.muatContoh();
						},
						children: "Muat contoh"
					})]
				})
			]
		}),
		profil ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfilDialog, {
			open: true,
			onClose: () => setProfil(false)
		}) : null,
		pabrik !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PabrikDialog, {
			open: true,
			onClose: () => setPabrik(void 0),
			awal: pabrik ?? void 0
		}) : null,
		penjahit !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenjahitDialog, {
			open: true,
			onClose: () => setPenjahit(void 0),
			awal: penjahit ?? void 0
		}) : null,
		model !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModelDialog, {
			open: true,
			onClose: () => setModel(void 0),
			awal: model ?? void 0
		}) : null
	] });
}
function Blok({ title, onAdd, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mb-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-2 flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				className: "px-3",
				onClick: onAdd,
				children: "Tambah"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col gap-2",
			children
		})]
	});
}
function Baris({ judul, sub, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "w-full rounded-2xl border border-line bg-surface px-4 py-3 text-left",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block font-semibold",
			children: judul
		}), sub ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-sm text-muted",
			children: sub
		}) : null]
	}) });
}
var SplitComponent = DataPage;
//#endregion
export { SplitComponent as component };
