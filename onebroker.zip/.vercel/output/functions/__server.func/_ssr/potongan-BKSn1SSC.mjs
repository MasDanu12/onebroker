import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { E as sisaPotongan, I as Page, L as PageHead, M as Button, N as EmptyState, c as angka, f as rupiah, g as namaDari, o as useBuku, p as tgl } from "./router-D8i6Q1Lc.mjs";
import { t as ContohBanner } from "./contoh-B6Wjm7H1.mjs";
import { n as BagiDialog, t as AmbilDialog } from "./forms-barang-C0_jLVfW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/potongan-BKSn1SSC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PotonganPage() {
	const data = useBuku();
	const [ambil, setAmbil] = (0, import_react.useState)(false);
	const [editId, setEditId] = (0, import_react.useState)(null);
	const [bagi, setBagi] = (0, import_react.useState)(null);
	const [cari, setCari] = (0, import_react.useState)("");
	const rows = (0, import_react.useMemo)(() => {
		return data.pengambilan.map((p) => {
			const jobs = data.pekerjaan.filter((k) => k.pengambilanId === p.id);
			return {
				...p,
				sisa: sisaPotongan(p, data.pekerjaan),
				jobs,
				model: namaDari(data.model, p.modelId),
				pabrik: namaDari(data.pabrik, p.pabrikId)
			};
		}).filter((p) => `${p.nomor} ${p.model} ${p.pabrik}`.toLowerCase().includes(cari.toLowerCase())).sort((a, b) => Number(b.sisa > 0) - Number(a.sisa > 0) || b.tanggal.localeCompare(a.tanggal));
	}, [data, cari]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContohBanner, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			title: "Potongan",
			lede: "Barang masuk dari pabrik. Yang belum dibagi masih belum punya penjahit.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setAmbil(true),
				children: "Ambil potongan"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value: cari,
			onChange: (e) => setCari(e.target.value),
			placeholder: "Cari pabrik atau model",
			className: "mb-4 h-11 w-full rounded-xl border border-line bg-surface px-3 text-base"
		}),
		rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			title: "Belum ada potongan",
			body: "Catat saat mengambil kain dari pabrik: qty, model, dan ongkos per pcs yang akan ditagih nanti.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setAmbil(true),
				children: "Ambil potongan"
			})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col gap-3",
			children: rows.map((p) => {
				const pct = p.qty === 0 ? 0 : Math.round((p.qty - p.sisa) / p.qty * 100);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-2xl border border-line bg-surface p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-semibold tracking-wide text-muted",
										children: p.nomor
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-2xl",
										children: p.model
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm text-muted",
										children: [
											p.pabrik,
											" · ",
											tgl(p.tanggal)
										]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-semibold tabular-nums",
									children: [angka(p.qty), " pcs"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm tabular-nums text-muted",
									children: [rupiah(p.hargaPerPcs), " / pcs"]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 h-2 overflow-hidden rounded-full bg-sunken",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full bg-pine",
								style: { width: `${pct}%` }
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm",
							children: [
								"Dibagi ",
								angka(p.qty - p.sisa),
								" · sisa",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-semibold",
									children: [angka(p.sisa), " pcs"]
								}),
								p.sisa > 0 ? " belum punya penjahit" : ""
							]
						}),
						p.jobs.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-2 text-sm text-muted",
							children: p.jobs.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								namaDari(data.penjahit, k.penjahitId),
								" · ",
								angka(k.qty),
								" pcs"
							] }, k.id))
						}) : null,
						p.catatan ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: p.catatan
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: [
								p.sisa > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									className: "px-3",
									onClick: () => setBagi(p.id),
									children: "Bagi ke penjahit"
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									className: "px-3",
									onClick: () => setEditId(p.id),
									children: "Ubah"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/cetak/ambil/$id",
									params: { id: p.id },
									className: "inline-flex h-11 items-center rounded-xl px-3 text-sm font-semibold text-pine",
									children: "Cetak nota ambil"
								})
							]
						})
					]
				}, p.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AmbilDialog, {
			open: ambil || editId !== null,
			onClose: () => {
				setAmbil(false);
				setEditId(null);
			},
			editId: editId ?? void 0
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BagiDialog, {
			open: bagi !== null,
			onClose: () => setBagi(null),
			awalPengambilanId: bagi ?? void 0
		})
	] });
}
var SplitComponent = PotonganPage;
//#endregion
export { SplitComponent as component };
