import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { d as Banknote, n as Wallet, o as Scissors, r as Truck, s as Package, u as Clock } from "../_libs/lucide-react.mjs";
import { A as upahMengambang, B as StatusBadge, C as saldoPabrik, D as statusKerja, E as sisaPotongan, I as Page, L as PageHead, M as Button, b as qtyBisaTagih, c as angka, d as nextPay, f as rupiah, g as namaDari, k as untungDisetor, l as bulanLabel, m as chartModel, o as useBuku, p as tgl, s as HARI, u as jakartaToday, w as saldoPenjahit, x as qtyMasihJahit, z as StatCard } from "./router-D8i6Q1Lc.mjs";
import { t as ContohBanner } from "./contoh-B6Wjm7H1.mjs";
import { a as TerimaDialog, t as BayarDialog } from "./forms-uang-BfwMHYUm.mjs";
import { n as BagiDialog, t as AmbilDialog } from "./forms-barang-C0_jLVfW.mjs";
import { a as ResponsiveContainer, i as Bar, n as YAxis, o as Tooltip, r as XAxis, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-bQMAL4zH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Dashboard() {
	const data = useBuku();
	const today = jakartaToday();
	const month = today.slice(0, 7);
	const bayar = nextPay(data.profil.hariBayar, today);
	const [ambil, setAmbil] = (0, import_react.useState)(false);
	const [bagi, setBagi] = (0, import_react.useState)(null);
	const [terima, setTerima] = (0, import_react.useState)(null);
	const [upah, setUpah] = (0, import_react.useState)(null);
	const belum = data.pengambilan.map((p) => ({
		...p,
		sisa: sisaPotongan(p, data.pekerjaan)
	})).filter((p) => p.sisa > 0);
	const pcsBelum = belum.reduce((a, p) => a + p.sisa, 0);
	const berjalan = data.pekerjaan.filter((k) => qtyMasihJahit(k) > 0);
	const pcsJahit = berjalan.reduce((a, k) => a + qtyMasihJahit(k), 0);
	const siapSetor = data.pekerjaan.filter((k) => statusKerja(k) === "menunggu-setor");
	const pcsTagih = data.pekerjaan.filter((k) => qtyBisaTagih(k) > 0).reduce((a, k) => a + qtyBisaTagih(k), 0);
	const pabrik = saldoPabrik(data);
	const piutang = pabrik.reduce((a, p) => a + Math.max(0, p.sisa), 0);
	const muka = pabrik.reduce((a, p) => a + Math.max(0, -p.sisa), 0);
	const penjahit = saldoPenjahit(data).filter((p) => p.upahBelum > 0 || p.kasbon > 0 || p.pcsJalan > 0);
	const upahJatuh = saldoPenjahit(data).reduce((a, p) => a + p.upahBelum, 0);
	const hasil = untungDisetor(data, month);
	const kas = data.kas.reduce((a, k) => {
		return a + (k.jenis === "modal" || k.jenis === "terima_pabrik" || k.jenis === "muka_pabrik" ? k.jumlah : -k.jumlah);
	}, 0);
	const chart = chartModel(data, month);
	const mengambang = upahMengambang(data);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContohBanner, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			title: bayar.hariIni ? `Hari ini ${HARI[data.profil.hariBayar]}` : `Bayar ${tgl(bayar.tanggal)}`,
			lede: "Ambil potongan, bagi ke penjahit, setor yang jadi, lalu tagih pabrik. Upah biasanya dibereskan di hari bayar.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => setAmbil(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, { className: "size-4" }), "Ambil potongan"]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: kas < 0 ? "mb-4 rounded-2xl bg-primary px-4 py-4 text-primary-fg" : "mb-4 rounded-2xl bg-pine px-4 py-4 text-pine-fg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-4" }), "Kas sekarang"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-display text-4xl tabular-nums",
					children: rupiah(kas)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-xl text-sm leading-6 opacity-90",
					children: kas < 0 ? "Minus ini uang pribadi yang belum kembali. Nanti saat pabrik transfer, catat di terima uang supaya kas naik lagi." : muka > 0 ? `Termasuk uang muka pabrik ${rupiah(muka)} yang belum ketutup tagihan.` : "Uang yang ada di kas usaha. Bayar penjahit dari sini, atau catat kalau pakai uang pribadi."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						className: "bg-surface text-fg",
						onClick: () => setTerima(""),
						children: "Terima dari pabrik"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						className: "bg-surface text-fg",
						onClick: () => setUpah(""),
						children: "Bayar upah"
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "grid grid-cols-2 gap-3 lg:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					to: "/potongan",
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, { className: "size-4" }),
					label: "Belum dibagi",
					value: angka(pcsBelum),
					hint: "pcs belum ada penjahitnya"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					to: "/kerja",
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scissors, { className: "size-4" }),
					label: "Sedang dijahit",
					value: angka(pcsJahit),
					hint: "pcs masih di penjahit"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					to: "/kerja",
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, { className: "size-4" }),
					label: "Siap disetor",
					value: angka(siapSetor.reduce((a, k) => a + (k.qtySelesai - k.qtySetor), 0)),
					hint: "pcs bagus, belum ke pabrik"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					to: "/nota",
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banknote, { className: "size-4" }),
					label: "Siap ditagih",
					value: angka(pcsTagih),
					hint: "pcs sudah disetor"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					to: "/kas",
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banknote, { className: "size-4" }),
					label: "Piutang pabrik",
					value: rupiah(piutang),
					hint: "yang belum mereka bayar"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					to: "/kas",
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-4" }),
					label: "Upah jatuh tempo",
					value: rupiah(upahJatuh),
					hint: `biasanya tiap ${HARI[data.profil.hariBayar]}`
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6 grid gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Belum ada penjahitnya",
				kosong: belum.length === 0,
				kosongText: "Semua potongan sudah dibagi.",
				children: belum.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between gap-3 border-b border-line py-3 last:border-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-semibold",
							children: namaDari(data.model, p.modelId)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								namaDari(data.pabrik, p.pabrikId),
								" · ",
								p.nomor,
								" · ",
								tgl(p.tanggal)
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums text-sm font-semibold",
							children: [angka(p.sisa), " pcs"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							className: "px-3",
							onClick: () => setBagi(p.id),
							children: "Bagi"
						})]
					})]
				}, p.id))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Pekerjaan yang sedang berjalan",
				kosong: berjalan.length === 0,
				kosongText: "Tidak ada yang masih dijahit.",
				children: berjalan.map((k) => {
					const amb = data.pengambilan.find((p) => p.id === k.pengambilanId);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border-b border-line py-3 last:border-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-semibold",
									children: namaDari(data.penjahit, k.penjahitId)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-muted",
									children: [
										namaDari(data.model, amb?.modelId ?? ""),
										" · ",
										namaDari(data.pabrik, amb?.pabrikId ?? "")
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: statusKerja(k) })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm tabular-nums text-muted",
							children: [
								"Masih ",
								angka(qtyMasihJahit(k)),
								" dari ",
								angka(k.qty),
								" pcs · dibagi ",
								tgl(k.tanggalBagi)
							]
						})]
					}, k.id);
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mt-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: `Upah yang perlu dibayar · ${HARI[data.profil.hariBayar]}`,
				kosong: penjahit.filter((p) => p.upahBelum > 0).length === 0,
				kosongText: "Tidak ada upah jatuh tempo. Upah muncul setelah hasil bagus dicatat.",
				children: penjahit.filter((p) => p.upahBelum > 0).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between gap-3 border-b border-line py-3 last:border-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: p.penjahit.nama
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"Upah ",
							rupiah(p.upahBelum),
							p.kasbon > 0 ? ` · kasbon ${rupiah(p.kasbon)} · tunai ${rupiah(p.net)}` : ""
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						className: "px-3",
						onClick: () => setUpah(p.penjahit.id),
						children: "Bayar"
					})]
				}, p.penjahit.id))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-4 grid gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-2xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-display text-2xl",
						children: ["Hasil ", bulanLabel(month)]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Dihitung dari pcs yang sudah disetor ke pabrik."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-4 grid grid-cols-3 gap-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Pendapatan"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 font-semibold tabular-nums text-pine",
								children: rupiah(hasil.pendapatan)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Upah"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 font-semibold tabular-nums text-primary",
								children: rupiah(hasil.upah)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Selisih"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 font-semibold tabular-nums",
								children: rupiah(hasil.untung)
							})] })
						]
					}),
					mengambang > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm text-muted",
						children: [
							"Upah yang sudah jatuh tempo tapi barangnya belum disetor: ",
							rupiah(mengambang),
							". Belum masuk selisih."
						]
					}) : null,
					chart.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 h-52 w-full min-w-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
								data: chart,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "nama",
										tick: { fontSize: 12 },
										interval: 0
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										tick: { fontSize: 12 },
										tickFormatter: (v) => v >= 1e3 ? `${Math.round(v / 1e3)}rb` : String(v),
										width: 48
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
										formatter: (value) => rupiah(Number(value ?? 0)),
										contentStyle: {
											background: "var(--color-surface)",
											border: "1px solid var(--color-line)",
											borderRadius: 12
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
										dataKey: "pendapatan",
										name: "Pendapatan",
										fill: "var(--color-pine)",
										radius: 4
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
										dataKey: "upah",
										name: "Upah",
										fill: "var(--color-primary)",
										radius: 4
									})
								]
							})
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-muted",
						children: "Belum ada setoran bulan ini."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-2xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Saldo pabrik"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Minus berarti pabrik masih harus bayar. Lebih berarti mereka sudah transfer duluan."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-3",
						children: [pabrik.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "text-sm text-muted",
							children: "Belum ada pabrik."
						}) : null, pabrik.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3 border-b border-line py-3 last:border-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: p.pabrik.nama
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: p.sisa > 0 ? "Masih harus bayar" : p.sisa < 0 ? "Sudah bayar duluan" : "Lunas"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold tabular-nums",
									children: rupiah(Math.abs(p.sisa))
								}), p.sisa > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "text-sm font-semibold text-pine",
									onClick: () => setTerima(p.pabrik.id),
									children: "Catat terima"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/nota",
									className: "text-sm font-semibold text-pine",
									children: "Lihat nota"
								})]
							})]
						}, p.pabrik.id))]
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AmbilDialog, {
			open: ambil,
			onClose: () => setAmbil(false)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BagiDialog, {
			open: bagi !== null,
			onClose: () => setBagi(null),
			awalPengambilanId: bagi ?? void 0
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TerimaDialog, {
			open: terima !== null,
			onClose: () => setTerima(null),
			pabrikAwal: terima || void 0
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BayarDialog, {
			open: upah !== null,
			onClose: () => setUpah(null),
			penjahitAwal: upah || void 0
		})
	] });
}
function Panel({ title, children, kosong, kosongText }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-2xl border border-line bg-surface p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-2xl",
			children: title
		}), kosong ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm text-muted",
			children: kosongText
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-1",
			children
		})]
	});
}
var SplitComponent = Dashboard;
//#endregion
export { SplitComponent as component };
