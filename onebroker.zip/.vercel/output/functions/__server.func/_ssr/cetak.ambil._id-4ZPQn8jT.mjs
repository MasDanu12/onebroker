import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as Route$2 } from "./router-D8i6Q1Lc.mjs";
import { t as CetakAmbil } from "./cetak-D80nYhgE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cetak.ambil._id-4ZPQn8jT.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = function Halaman() {
	const { id } = Route$2.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CetakAmbil, { id });
};
//#endregion
export { SplitComponent as component };
