import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { F as Modal, M as Button, O as terimaTagihan, P as Field, R as Select, T as sisaKasbon, V as TextInput, b as qtyBisaTagih, f as rupiah, g as namaDari, j as Area, o as useBuku, u as jakartaToday, v as nilaiTagihan, y as qtyBisaBayar } from "./router-D8i6Q1Lc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/forms-uang-BfwMHYUm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function say(result, sukses) {
	if (!result.ok) {
		toast.error(result.error ?? "Gagal menyimpan.");
		return false;
	}
	toast.success(sukses);
	return true;
}
function TagihanDialog({ open, onClose, pabrikAwal }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onClose,
		title: "Buat tagihan pabrik",
		wide: true,
		children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TagihanForm, {
			pabrikAwal,
			onClose
		}, pabrikAwal ?? "baru") : null
	});
}
function TagihanForm({ pabrikAwal, onClose }) {
	const data = useBuku();
	const [pabrikId, setPabrikId] = (0, import_react.useState)(pabrikAwal || data.pabrik[0]?.id || "");
	const [tanggal, setTanggal] = (0, import_react.useState)(jakartaToday());
	const [catatan, setCatatan] = (0, import_react.useState)("");
	const baris = (0, import_react.useMemo)(() => data.pekerjaan.map((k) => {
		return {
			k,
			amb: data.pengambilan.find((p) => p.id === k.pengambilanId),
			bisa: qtyBisaTagih(k)
		};
	}).filter((row) => row.amb?.pabrikId === pabrikId && row.bisa > 0), [
		data.pekerjaan,
		data.pengambilan,
		pabrikId
	]);
	const [qty, setQty] = (0, import_react.useState)({});
	const [on, setOn] = (0, import_react.useState)({});
	function nilai(id, bisa) {
		if (on[id] === false) return 0;
		const raw = qty[id];
		if (raw == null || raw === "") return bisa;
		return Math.min(bisa, Number(raw.replace(/\D/g, "")) || 0);
	}
	const total = baris.reduce((a, row) => a + nilai(row.k.id, row.bisa) * (row.amb?.hargaPerPcs ?? 0), 0);
	function simpan() {
		const lines = baris.map((row) => ({
			pekerjaanId: row.k.id,
			qty: nilai(row.k.id, row.bisa)
		})).filter((l) => l.qty > 0);
		if (say(data.buatTagihan({
			pabrikId,
			tanggal,
			catatan,
			lines
		}), "Tagihan dibuat. Bisa dicetak dari menu Nota.")) onClose();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (e) => {
			e.preventDefault();
			simpan();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Pabrik",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					value: pabrikId,
					onChange: (e) => setPabrikId(e.target.value),
					children: data.pabrik.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: p.id,
						children: p.nama
					}, p.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Tanggal tagihan",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					type: "date",
					value: tanggal,
					onChange: (e) => setTanggal(e.target.value)
				})
			}),
			baris.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-sm leading-6 text-muted",
				children: "Belum ada setoran yang belum ditagih untuk pabrik ini."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mb-3 flex flex-col gap-2",
				children: baris.map((row) => {
					const checked = on[row.k.id] !== false;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-xl border border-line p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								className: "mt-1 size-4",
								checked,
								onChange: (e) => setOn((s) => ({
									...s,
									[row.k.id]: e.target.checked
								}))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block text-sm font-semibold",
									children: [
										namaDari(data.model, row.amb?.modelId ?? ""),
										" · ",
										namaDari(data.penjahit, row.k.penjahitId)
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block text-xs text-muted",
									children: [
										row.k.nomor,
										" · bisa ditagih ",
										row.bisa,
										" pcs · ",
										rupiah(row.amb?.hargaPerPcs ?? 0)
									]
								})]
							})]
						}), checked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							className: "mt-2",
							inputMode: "numeric",
							value: qty[row.k.id] ?? String(row.bisa),
							onChange: (e) => setQty((s) => ({
								...s,
								[row.k.id]: e.target.value
							})),
							"aria-label": "Qty ditagih"
						}) : null]
					}, row.k.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-3 text-sm",
				children: ["Total tagihan: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-semibold tabular-nums",
					children: rupiah(total)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Catatan",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
					value: catatan,
					onChange: (e) => setCatatan(e.target.value),
					placeholder: "Misalnya pcs rusak yang tidak ditagih"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					children: "Buat tagihan"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: onClose,
					children: "Batal"
				})]
			})
		]
	});
}
function TerimaDialog({ open, onClose, pabrikAwal }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onClose,
		title: "Terima uang pabrik",
		children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TerimaForm, {
			pabrikAwal,
			onClose
		}, pabrikAwal ?? "baru") : null
	});
}
function TerimaForm({ pabrikAwal, onClose }) {
	const data = useBuku();
	const [pabrikId, setPabrikId] = (0, import_react.useState)(pabrikAwal || data.pabrik[0]?.id || "");
	const [jenis, setJenis] = (0, import_react.useState)("terima_pabrik");
	const tagihan = data.tagihan.filter((t) => t.pabrikId === pabrikId);
	const [tagihanId, setTagihanId] = (0, import_react.useState)("");
	const sisa = (() => {
		const t = tagihan.find((x) => x.id === tagihanId);
		if (!t) return 0;
		return Math.max(0, nilaiTagihan(t) - terimaTagihan(t.id, data.kas));
	})();
	const [jumlah, setJumlah] = (0, import_react.useState)("");
	const [tanggal, setTanggal] = (0, import_react.useState)(jakartaToday());
	const [catatan, setCatatan] = (0, import_react.useState)("");
	function simpan() {
		if (say(data.terimaPabrik({
			pabrikId,
			tanggal,
			jumlah: Number(jumlah.replace(/\D/g, "")),
			jenis,
			tagihanId: jenis === "terima_pabrik" ? tagihanId : "",
			catatan
		}), "Uang masuk dicatat. Kas bertambah.")) onClose();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (e) => {
			e.preventDefault();
			simpan();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Pabrik",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					value: pabrikId,
					onChange: (e) => {
						setPabrikId(e.target.value);
						setTagihanId("");
					},
					children: data.pabrik.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: p.id,
						children: p.nama
					}, p.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setJenis("terima_pabrik"),
					className: jenis === "terima_pabrik" ? "h-11 rounded-xl bg-pine text-sm font-semibold text-pine-fg" : "h-11 rounded-xl border border-line text-sm font-semibold",
					children: "Pelunasan"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setJenis("muka_pabrik"),
					className: jenis === "muka_pabrik" ? "h-11 rounded-xl bg-pine text-sm font-semibold text-pine-fg" : "h-11 rounded-xl border border-line text-sm font-semibold",
					children: "Bayar duluan"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-xs leading-5 text-muted",
				children: jenis === "muka_pabrik" ? "Pakai ini kalau pabrik transfer sebelum tagihan terbit. Nanti mengurangi sisa yang harus mereka bayar." : "Pakai ini kalau pabrik membayar tagihan. Boleh dikaitkan ke satu nota."
			}),
			jenis === "terima_pabrik" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Kaitkan ke tagihan",
				hint: "Boleh dikosongkan kalau uangnya untuk saldo pabrik secara umum.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: tagihanId,
					onChange: (e) => setTagihanId(e.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Tidak dikaitkan"
					}), tagihan.map((t) => {
						const s = nilaiTagihan(t) - terimaTagihan(t.id, data.kas);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: t.id,
							children: [
								t.nomor,
								" · sisa ",
								rupiah(s)
							]
						}, t.id);
					})]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Jumlah diterima",
				hint: sisa > 0 ? `Sisa tagihan yang dipilih ${rupiah(sisa)}.` : void 0,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					inputMode: "numeric",
					value: jumlah,
					placeholder: sisa > 0 ? String(sisa) : "0",
					onChange: (e) => setJumlah(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Tanggal",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					type: "date",
					value: tanggal,
					onChange: (e) => setTanggal(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Catatan",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
					value: catatan,
					onChange: (e) => setCatatan(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					variant: "pine",
					children: "Simpan"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: onClose,
					children: "Batal"
				})]
			})
		]
	});
}
function BayarDialog({ open, onClose, penjahitAwal }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onClose,
		title: "Bayar upah penjahit",
		wide: true,
		children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BayarForm, {
			penjahitAwal,
			onClose
		}, penjahitAwal ?? "baru") : null
	});
}
function BayarForm({ penjahitAwal, onClose }) {
	const data = useBuku();
	const [penjahitId, setPenjahitId] = (0, import_react.useState)(penjahitAwal || data.penjahit[0]?.id || "");
	const [tanggal, setTanggal] = (0, import_react.useState)(jakartaToday());
	const [catatan, setCatatan] = (0, import_react.useState)("");
	const jobs = data.pekerjaan.filter((k) => k.penjahitId === penjahitId && qtyBisaBayar(k) > 0);
	const [qty, setQty] = (0, import_react.useState)({});
	const [on, setOn] = (0, import_react.useState)({});
	const kasbon = sisaKasbon(penjahitId, data.kas, data.slip);
	function nilai(id, bisa) {
		if (on[id] === false) return 0;
		const raw = qty[id];
		if (raw == null || raw === "") return bisa;
		return Math.min(bisa, Number(raw.replace(/\D/g, "")) || 0);
	}
	const bruto = jobs.reduce((a, k) => a + nilai(k.id, qtyBisaBayar(k)) * k.upahPerPcs, 0);
	const [potongInput, setPotongInput] = (0, import_react.useState)(null);
	const potongDefault = Math.min(kasbon, bruto);
	const potong = potongInput == null ? potongDefault : Math.min(bruto, Number(potongInput.replace(/\D/g, "")) || 0);
	const tunai = Math.max(0, bruto - potong);
	const kas = data.kas.reduce((a, k) => {
		return a + (k.jenis === "modal" || k.jenis === "terima_pabrik" || k.jenis === "muka_pabrik" ? k.jumlah : -k.jumlah);
	}, 0);
	function simpan() {
		const lines = jobs.map((k) => ({
			pekerjaanId: k.id,
			qty: nilai(k.id, qtyBisaBayar(k))
		})).filter((l) => l.qty > 0);
		if (say(data.bayarUpah({
			penjahitId,
			tanggal,
			catatan,
			potongKasbon: potong,
			lines
		}), "Upah dicatat. Slip bisa dicetak dari menu Nota.")) onClose();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (e) => {
			e.preventDefault();
			simpan();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Penjahit",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					value: penjahitId,
					onChange: (e) => {
						setPenjahitId(e.target.value);
						setPotongInput(null);
						setQty({});
						setOn({});
					},
					children: data.penjahit.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: p.id,
						children: p.nama
					}, p.id))
				})
			}),
			jobs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-sm leading-6 text-muted",
				children: "Belum ada upah yang jatuh tempo. Catat dulu hasil jahitan yang bagus."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mb-3 flex flex-col gap-2",
				children: jobs.map((k) => {
					const amb = data.pengambilan.find((p) => p.id === k.pengambilanId);
					const bisa = qtyBisaBayar(k);
					const checked = on[k.id] !== false;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-xl border border-line p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								className: "mt-1 size-4",
								checked,
								onChange: (e) => setOn((s) => ({
									...s,
									[k.id]: e.target.checked
								}))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block text-sm font-semibold",
								children: [
									namaDari(data.model, amb?.modelId ?? ""),
									" · ",
									k.nomor
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block text-xs text-muted",
								children: [
									bisa,
									" pcs × ",
									rupiah(k.upahPerPcs)
								]
							})] })]
						}), checked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							className: "mt-2",
							inputMode: "numeric",
							"aria-label": "Qty dibayar",
							value: qty[k.id] ?? String(bisa),
							onChange: (e) => setQty((s) => ({
								...s,
								[k.id]: e.target.value
							}))
						}) : null]
					}, k.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Potong kasbon",
				hint: `Sisa kasbon ${rupiah(kasbon)}. Tidak mengurangi kas lagi karena uangnya sudah keluar waktu kasbon.`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					inputMode: "numeric",
					value: potongInput ?? String(potongDefault),
					onChange: (e) => setPotongInput(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 rounded-xl bg-ink-soft p-3 text-sm leading-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Upah kotor: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: rupiah(bruto)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Potong kasbon: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: rupiah(potong)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-semibold",
						children: ["Tunai yang diberikan: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: rupiah(tunai)
						})]
					}),
					tunai > kas ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-primary",
						children: [
							"Kas sekarang ",
							rupiah(kas),
							". Setelah ini kas minus ",
							rupiah(tunai - kas),
							" — itu uang pribadi yang belum balik."
						]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Tanggal",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					type: "date",
					value: tanggal,
					onChange: (e) => setTanggal(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Catatan",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
					value: catatan,
					onChange: (e) => setCatatan(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					children: "Simpan & buat slip"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: onClose,
					children: "Batal"
				})]
			})
		]
	});
}
function KasbonDialog({ open, onClose, penjahitAwal }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onClose,
		title: "Kasbon penjahit",
		children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KasbonForm, {
			penjahitAwal,
			onClose
		}, penjahitAwal ?? "baru") : null
	});
}
function KasbonForm({ penjahitAwal, onClose }) {
	const data = useBuku();
	const [penjahitId, setPenjahitId] = (0, import_react.useState)(penjahitAwal || data.penjahit[0]?.id || "");
	const [jumlah, setJumlah] = (0, import_react.useState)("");
	const [tanggal, setTanggal] = (0, import_react.useState)(jakartaToday());
	const [catatan, setCatatan] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (e) => {
			e.preventDefault();
			if (say(data.kasihKasbon({
				penjahitId,
				tanggal,
				jumlah: Number(jumlah.replace(/\D/g, "")),
				catatan
			}), "Kasbon dicatat. Nanti dipotong saat bayar upah.")) onClose();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Penjahit",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					value: penjahitId,
					onChange: (e) => setPenjahitId(e.target.value),
					children: data.penjahit.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: p.id,
						children: p.nama
					}, p.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Jumlah kasbon",
				hint: "Uang ini keluar sekarang. Saat Sabtu, potong dari upah supaya tidak dibayar dua kali.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					inputMode: "numeric",
					value: jumlah,
					onChange: (e) => setJumlah(e.target.value),
					placeholder: "100000"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Tanggal",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					type: "date",
					value: tanggal,
					onChange: (e) => setTanggal(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Catatan",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
					value: catatan,
					onChange: (e) => setCatatan(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					children: "Simpan"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: onClose,
					children: "Batal"
				})]
			})
		]
	});
}
function PribadiDialog({ open, onClose }) {
	const data = useBuku();
	const [jenis, setJenis] = (0, import_react.useState)("modal");
	const [jumlah, setJumlah] = (0, import_react.useState)("");
	const [tanggal, setTanggal] = (0, import_react.useState)(jakartaToday());
	const [catatan, setCatatan] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onClose,
		title: "Uang pribadi",
		children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: (e) => {
				e.preventDefault();
				if (say(data.uangPribadi({
					jenis,
					tanggal,
					jumlah: Number(jumlah.replace(/\D/g, "")),
					catatan
				}), jenis === "modal" ? "Uang pribadi masuk ke kas." : "Uang ditarik ke dompet.")) onClose();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setJenis("modal"),
						className: jenis === "modal" ? "h-11 rounded-xl bg-fg text-sm font-semibold text-surface" : "h-11 rounded-xl border border-line text-sm font-semibold",
						children: "Masukkan ke kas"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setJenis("tarik"),
						className: jenis === "tarik" ? "h-11 rounded-xl bg-fg text-sm font-semibold text-surface" : "h-11 rounded-xl border border-line text-sm font-semibold",
						children: "Tarik ke dompet"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-xs leading-5 text-muted",
					children: "Kalau bayar penjahit dulu dan kas jadi minus, itu sudah terhitung uang pribadi. Formulir ini untuk mencatat setoran atau penarikan yang memang sengaja."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Jumlah",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						inputMode: "numeric",
						value: jumlah,
						onChange: (e) => setJumlah(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Tanggal",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						type: "date",
						value: tanggal,
						onChange: (e) => setTanggal(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Catatan",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
						value: catatan,
						onChange: (e) => setCatatan(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: "Simpan"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: onClose,
						children: "Batal"
					})]
				})
			]
		}) : null
	});
}
//#endregion
export { TerimaDialog as a, TagihanDialog as i, KasbonDialog as n, PribadiDialog as r, BayarDialog as t };
