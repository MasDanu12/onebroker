import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { E as sisaPotongan, F as Modal, M as Button, P as Field, R as Select, V as TextInput, f as rupiah, g as namaDari, j as Area, o as useBuku, u as jakartaToday } from "./router-D8i6Q1Lc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/forms-barang-C0_jLVfW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PilihAtauBaru({ label, value, onChange, options, baru, onBaru, namaBaru, onNama, kosong }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
		label,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
			value: baru ? "__baru" : value,
			onChange: (e) => {
				if (e.target.value === "__baru") onBaru(true);
				else {
					onBaru(false);
					onChange(e.target.value);
				}
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: "",
					children: kosong
				}),
				options.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: o.id,
					children: o.nama
				}, o.id)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: "__baru",
					children: "+ Tambah baru"
				})
			]
		}), baru ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
			className: "mt-2",
			value: namaBaru,
			placeholder: `Nama ${label.toLowerCase()}`,
			onChange: (e) => onNama(e.target.value),
			autoFocus: true
		}) : null]
	});
}
function say(result, sukses) {
	if (!result.ok) {
		toast.error(result.ok ? "" : result.error);
		return false;
	}
	toast.success(sukses);
	return true;
}
function AmbilDialog({ open, onClose, editId }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onClose,
		title: editId ? "Ubah pengambilan" : "Ambil potongan",
		children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AmbilForm, {
			editId,
			onClose
		}, editId ?? "baru") : null
	});
}
function AmbilForm({ editId, onClose }) {
	const data = useBuku();
	const lama = data.pengambilan.find((p) => p.id === editId);
	const [tanggal, setTanggal] = (0, import_react.useState)(lama?.tanggal ?? jakartaToday());
	const [pabrikId, setPabrikId] = (0, import_react.useState)(lama?.pabrikId ?? data.pabrik[0]?.id ?? "");
	const [modelId, setModelId] = (0, import_react.useState)(lama?.modelId ?? data.model[0]?.id ?? "");
	const [qty, setQty] = (0, import_react.useState)(String(lama?.qty ?? ""));
	const [harga, setHarga] = (0, import_react.useState)(String(lama?.hargaPerPcs ?? data.model[0]?.hargaPabrik ?? ""));
	const [catatan, setCatatan] = (0, import_react.useState)(lama?.catatan ?? "");
	const [pabrikBaru, setPabrikBaru] = (0, import_react.useState)(false);
	const [namaPabrik, setNamaPabrik] = (0, import_react.useState)("");
	const [modelBaru, setModelBaru] = (0, import_react.useState)(false);
	const [namaModel, setNamaModel] = (0, import_react.useState)("");
	function pilihModel(id) {
		setModelId(id);
		const m = data.model.find((x) => x.id === id);
		if (m && !lama) setHarga(String(m.hargaPabrik));
	}
	function simpan() {
		let pid = pabrikId;
		if (pabrikBaru) {
			const r = data.simpanPabrik({
				nama: namaPabrik,
				telepon: "",
				alamat: "",
				catatan: ""
			});
			if (!r.ok || !r.id) return say(r, "");
			pid = r.id;
		}
		let mid = modelId;
		if (modelBaru) {
			const hargaAwal = Number(harga.replace(/\D/g, "")) || 0;
			const r = data.simpanModel({
				nama: namaModel,
				hargaPabrik: hargaAwal,
				upahJahit: 0
			});
			if (!r.ok || !r.id) return say(r, "");
			mid = r.id;
		}
		if (say(data.ambilPotongan({
			id: editId,
			tanggal,
			pabrikId: pid,
			modelId: mid,
			qty: Number(qty.replace(/\D/g, "")),
			hargaPerPcs: Number(harga.replace(/\D/g, "")),
			catatan
		}), editId ? "Pengambilan diubah." : "Potongan dicatat.")) onClose();
	}
	const q = Number(qty.replace(/\D/g, "")) || 0;
	const h = Number(harga.replace(/\D/g, "")) || 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (e) => {
			e.preventDefault();
			simpan();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Tanggal ambil",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					type: "date",
					value: tanggal,
					onChange: (e) => setTanggal(e.target.value),
					required: true
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PilihAtauBaru, {
				label: "Pabrik",
				value: pabrikId,
				onChange: setPabrikId,
				options: data.pabrik,
				baru: pabrikBaru,
				onBaru: setPabrikBaru,
				namaBaru: namaPabrik,
				onNama: setNamaPabrik,
				kosong: "Pilih pabrik"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PilihAtauBaru, {
				label: "Model",
				value: modelId,
				onChange: pilihModel,
				options: data.model,
				baru: modelBaru,
				onBaru: setModelBaru,
				namaBaru: namaModel,
				onNama: setNamaModel,
				kosong: "Pilih model"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Qty (pcs)",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					inputMode: "numeric",
					value: qty,
					onChange: (e) => setQty(e.target.value),
					placeholder: "100",
					required: true
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Ongkos dari pabrik per pcs",
				hint: "Ini harga yang nanti ditagihkan, bukan uang yang keluar sekarang.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					inputMode: "numeric",
					value: harga,
					onChange: (e) => setHarga(e.target.value),
					placeholder: "5000"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-3 text-sm text-muted",
				children: ["Perkiraan tagihan kalau semua beres: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-semibold text-fg tabular-nums",
					children: rupiah(q * h)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Catatan",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
					value: catatan,
					onChange: (e) => setCatatan(e.target.value),
					placeholder: "Warna, no PO, atau catatan lain"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: "Simpan"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: onClose,
						children: "Batal"
					}),
					editId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "danger",
						onClick: () => {
							if (!window.confirm("Hapus pengambilan ini?")) return;
							if (say(data.hapusPengambilan(editId), "Pengambilan dihapus.")) onClose();
						},
						children: "Hapus"
					}) : null
				]
			})
		]
	});
}
function BagiDialog({ open, onClose, awalPengambilanId }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onClose,
		title: "Bagi ke penjahit",
		children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BagiForm, {
			awalPengambilanId,
			onClose
		}, awalPengambilanId ?? "baru") : null
	});
}
function BagiForm({ awalPengambilanId, onClose }) {
	const data = useBuku();
	const siap = data.pengambilan.map((p) => ({
		...p,
		sisa: sisaPotongan(p, data.pekerjaan)
	})).filter((p) => p.sisa > 0);
	const awal = siap.find((p) => p.id === awalPengambilanId) ?? siap[0];
	const [pengambilanId, setPengambilanId] = (0, import_react.useState)(awal?.id ?? "");
	const current = siap.find((p) => p.id === pengambilanId) ?? awal;
	const model = data.model.find((m) => m.id === current?.modelId);
	const [penjahitId, setPenjahitId] = (0, import_react.useState)(data.penjahit[0]?.id ?? "");
	const [baru, setBaru] = (0, import_react.useState)(false);
	const [namaBaru, setNamaBaru] = (0, import_react.useState)("");
	const [qty, setQty] = (0, import_react.useState)(String(current?.sisa ?? ""));
	const [upah, setUpah] = (0, import_react.useState)(String(model?.upahJahit ?? ""));
	const [tanggal, setTanggal] = (0, import_react.useState)(jakartaToday());
	const [catatan, setCatatan] = (0, import_react.useState)("");
	function gantiPotongan(id) {
		setPengambilanId(id);
		const p = siap.find((x) => x.id === id);
		const m = data.model.find((x) => x.id === p?.modelId);
		setQty(String(p?.sisa ?? ""));
		if (m) setUpah(String(m.upahJahit));
	}
	function simpan() {
		let pid = penjahitId;
		if (baru) {
			const r = data.simpanPenjahit({
				nama: namaBaru,
				telepon: "",
				alamat: "",
				catatan: ""
			});
			if (!r.ok || !r.id) return say(r, "");
			pid = r.id;
		}
		if (say(data.bagiKerja({
			pengambilanId,
			penjahitId: pid,
			tanggal,
			qty: Number(qty.replace(/\D/g, "")),
			upahPerPcs: Number(upah.replace(/\D/g, "")),
			catatan
		}), "Potongan sudah dibagi.")) onClose();
	}
	if (siap.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm leading-6 text-muted",
		children: "Semua potongan sudah dibagi. Ambil dulu dari pabrik kalau ada order baru."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (e) => {
			e.preventDefault();
			simpan();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Potongan",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "h-11 w-full rounded-xl border border-line bg-surface px-3",
					value: pengambilanId,
					onChange: (e) => gantiPotongan(e.target.value),
					children: siap.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
						value: p.id,
						children: [
							p.nomor,
							" · ",
							namaDari(data.model, p.modelId),
							" · ",
							namaDari(data.pabrik, p.pabrikId),
							" · sisa ",
							p.sisa
						]
					}, p.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PilihAtauBaru, {
				label: "Penjahit",
				value: penjahitId,
				onChange: setPenjahitId,
				options: data.penjahit,
				baru,
				onBaru: setBaru,
				namaBaru,
				onNama: setNamaBaru,
				kosong: "Pilih penjahit"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Qty yang dibagi",
				hint: current ? `Maksimal ${current.sisa} pcs.` : void 0,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					inputMode: "numeric",
					value: qty,
					onChange: (e) => setQty(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Upah per pcs",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					inputMode: "numeric",
					value: upah,
					onChange: (e) => setUpah(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Tanggal bagi",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					type: "date",
					value: tanggal,
					onChange: (e) => setTanggal(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Catatan",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
					value: catatan,
					onChange: (e) => setCatatan(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					children: "Simpan"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: onClose,
					children: "Batal"
				})]
			})
		]
	});
}
function HasilDialog({ open, onClose, kerjaId }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onClose,
		title: "Catat hasil jahitan",
		wide: true,
		children: open && kerjaId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HasilForm, {
			kerjaId,
			onClose
		}, kerjaId) : null
	});
}
function HasilForm({ kerjaId, onClose }) {
	const data = useBuku();
	const k = data.pekerjaan.find((x) => x.id === kerjaId);
	const amb = data.pengambilan.find((p) => p.id === k?.pengambilanId);
	const [penjahitId, setPenjahitId] = (0, import_react.useState)(k?.penjahitId ?? "");
	const [qty, setQty] = (0, import_react.useState)(String(k?.qty ?? ""));
	const [upah, setUpah] = (0, import_react.useState)(String(k?.upahPerPcs ?? ""));
	const [bagus, setBagus] = (0, import_react.useState)(String(k?.qtySelesai ?? 0));
	const [rusak, setRusak] = (0, import_react.useState)(String(k?.qtyRusak ?? 0));
	const [setor, setSetor] = (0, import_react.useState)(String(k?.qtySetor ?? 0));
	const [tanggalBagi, setTanggalBagi] = (0, import_react.useState)(k?.tanggalBagi ?? jakartaToday());
	const [tanggalSelesai, setTanggalSelesai] = (0, import_react.useState)(k?.tanggalSelesai || jakartaToday());
	const [tanggalSetor, setTanggalSetor] = (0, import_react.useState)(k?.tanggalSetor || jakartaToday());
	const [catatan, setCatatan] = (0, import_react.useState)(k?.catatan ?? "");
	if (!k || !amb) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Pekerjaan tidak ditemukan." });
	const kerja = k;
	const q = Number(qty.replace(/\D/g, "")) || 0;
	const b = Number(bagus.replace(/\D/g, "")) || 0;
	const rsk = Number(rusak.replace(/\D/g, "")) || 0;
	function simpan() {
		if (say(data.ubahKerja(kerja.id, {
			penjahitId,
			tanggalBagi,
			qty: q,
			upahPerPcs: Number(upah.replace(/\D/g, "")) || 0,
			qtySelesai: b,
			qtyRusak: rsk,
			tanggalSelesai,
			qtySetor: Number(setor.replace(/\D/g, "")) || 0,
			tanggalSetor,
			catatan
		}), "Hasil jahitan disimpan.")) onClose();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (e) => {
			e.preventDefault();
			simpan();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-3 text-sm text-muted",
				children: [
					kerja.nomor,
					" · ",
					namaDari(data.model, amb.modelId),
					" · ",
					namaDari(data.pabrik, amb.pabrikId),
					" · ongkos ",
					rupiah(amb.hargaPerPcs)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Penjahit",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "h-11 w-full rounded-xl border border-line bg-surface px-3",
					value: penjahitId,
					onChange: (e) => setPenjahitId(e.target.value),
					children: data.penjahit.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: p.id,
						children: p.nama
					}, p.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Qty dipegang",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							inputMode: "numeric",
							value: qty,
							onChange: (e) => setQty(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Upah per pcs",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							inputMode: "numeric",
							value: upah,
							onChange: (e) => setUpah(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Bagus",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							inputMode: "numeric",
							value: bagus,
							onChange: (e) => setBagus(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Rusak / hilang",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							inputMode: "numeric",
							value: rusak,
							onChange: (e) => setRusak(e.target.value)
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-3 text-sm text-muted",
				children: [
					"Masih di penjahit: ",
					Math.max(0, q - b - rsk),
					" pcs. Upah dihitung dari yang bagus."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => {
						setRusak("0");
						setBagus(String(q));
					},
					children: "Bagus semua"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => setSetor(String(b)),
					children: "Setor semua yang bagus"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Sudah disetor ke pabrik",
				hint: "Yang disetor ini yang bisa ditagihkan.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					inputMode: "numeric",
					value: setor,
					onChange: (e) => setSetor(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Tanggal bagi",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							type: "date",
							value: tanggalBagi,
							onChange: (e) => setTanggalBagi(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Tanggal selesai",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							type: "date",
							value: tanggalSelesai,
							onChange: (e) => setTanggalSelesai(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Tanggal setor",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							type: "date",
							value: tanggalSetor,
							onChange: (e) => setTanggalSetor(e.target.value)
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Catatan",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
					value: catatan,
					onChange: (e) => setCatatan(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: "Simpan"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: onClose,
						children: "Batal"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "danger",
						onClick: () => {
							if (!window.confirm("Hapus pekerjaan ini?")) return;
							if (say(data.hapusKerja(kerja.id), "Pekerjaan dihapus.")) onClose();
						},
						children: "Hapus"
					})
				]
			})
		]
	});
}
//#endregion
export { BagiDialog as n, HasilDialog as r, AmbilDialog as t };
