import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { M as Button, o as useBuku } from "./router-D8i6Q1Lc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contoh-B6Wjm7H1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ContohBanner() {
	const contoh = useBuku((s) => s.contoh);
	const kosongkan = useBuku((s) => s.kosongkan);
	const [sembunyi, setSembunyi] = (0, import_react.useState)(false);
	if (!contoh || sembunyi) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-5 rounded-2xl border border-line bg-sunken px-4 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm leading-6",
			children: "Angka di layar ini contoh, supaya alur ambil–jahit–tagih kebaca. Hapus dulu kalau mau mulai catatan sendiri."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 flex flex-wrap gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: () => {
					if (window.confirm("Hapus semua data contoh dan mulai dari kosong?")) kosongkan();
				},
				children: "Mulai dari kosong"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				onClick: () => setSembunyi(true),
				children: "Nanti saja"
			})]
		})]
	});
}
//#endregion
export { ContohBanner as t };
