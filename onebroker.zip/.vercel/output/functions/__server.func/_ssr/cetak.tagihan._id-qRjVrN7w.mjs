import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as Route } from "./router-D8i6Q1Lc.mjs";
import { r as CetakTagihan } from "./cetak-D80nYhgE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cetak.tagihan._id-qRjVrN7w.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = function Halaman() {
	const { id } = Route.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CetakTagihan, { id });
};
//#endregion
export { SplitComponent as component };
