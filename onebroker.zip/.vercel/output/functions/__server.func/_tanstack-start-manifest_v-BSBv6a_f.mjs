//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BSBv6a_f.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/data",
			"/kas",
			"/kerja",
			"/nota",
			"/potongan",
			"/cetak/ambil/$id",
			"/cetak/slip/$id",
			"/cetak/tagihan/$id"
		],
		preloads: [
			"/assets/index-DV9PsLnP.js",
			"/assets/store-DBluSjvi.js",
			"/assets/ui-dpkajFjr.js",
			"/assets/preload-helper-Dww7gM6Z.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DV9PsLnP.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BPLDGZWQ.js",
			"/assets/contoh-zW_dK9N3.js",
			"/assets/forms-barang-D9NbbQMc.js",
			"/assets/forms-uang-Bbhex3QB.js"
		]
	},
	"/data": {
		filePath: "/workspace/src/routes/data.tsx",
		children: void 0,
		preloads: ["/assets/data-iQbuB99N.js", "/assets/contoh-zW_dK9N3.js"]
	},
	"/kas": {
		filePath: "/workspace/src/routes/kas.tsx",
		children: void 0,
		preloads: [
			"/assets/kas-Bz5o0foo.js",
			"/assets/contoh-zW_dK9N3.js",
			"/assets/forms-uang-Bbhex3QB.js"
		]
	},
	"/kerja": {
		filePath: "/workspace/src/routes/kerja.tsx",
		children: void 0,
		preloads: [
			"/assets/kerja-DPNwrPmG.js",
			"/assets/contoh-zW_dK9N3.js",
			"/assets/forms-barang-D9NbbQMc.js",
			"/assets/forms-uang-Bbhex3QB.js"
		]
	},
	"/nota": {
		filePath: "/workspace/src/routes/nota.tsx",
		children: void 0,
		preloads: [
			"/assets/nota-B_fNCL4s.js",
			"/assets/contoh-zW_dK9N3.js",
			"/assets/forms-uang-Bbhex3QB.js"
		]
	},
	"/potongan": {
		filePath: "/workspace/src/routes/potongan.tsx",
		children: void 0,
		preloads: [
			"/assets/potongan-DWQpuulg.js",
			"/assets/contoh-zW_dK9N3.js",
			"/assets/forms-barang-D9NbbQMc.js"
		]
	},
	"/cetak/ambil/$id": {
		filePath: "/workspace/src/routes/cetak.ambil.$id.tsx",
		children: void 0,
		preloads: ["/assets/cetak.ambil._id-DSAit7JI.js", "/assets/cetak-CydyvzAH.js"]
	},
	"/cetak/slip/$id": {
		filePath: "/workspace/src/routes/cetak.slip.$id.tsx",
		children: void 0,
		preloads: ["/assets/cetak.slip._id-DtdtMlT1.js", "/assets/cetak-CydyvzAH.js"]
	},
	"/cetak/tagihan/$id": {
		filePath: "/workspace/src/routes/cetak.tagihan.$id.tsx",
		children: void 0,
		preloads: ["/assets/cetak.tagihan._id-CCrCwOUY.js", "/assets/cetak-CydyvzAH.js"]
	}
} });
//#endregion
export { tsrStartManifest };
